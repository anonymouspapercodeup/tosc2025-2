#!/usr/bin/env python3
import argparse
import ast
import logging
from itertools import product
import os
import subprocess
import tempfile
import time
from typing import Tuple, List

from pysat.card import CardEnc
from pysat.formula import CNF
from pysat.solvers import Solver
from pysat.process import Processor

from modeling.AES_DCSAT import get_AES_DCSAT_clauses, print_solution
from modeling.ARIA_clauses import get_ARIA_DCSAT_Differential_clauses
from modeling.Camellia_clauses import get_Camellia_DCSAT_Differential_clauses
from modeling.LED_clauses import get_LED_DCSAT_clauses
from modeling.Midori128_clauses import get_Midori128_DCSAT_clauses
from modeling.Rijndael_DCSAT import get_Rijndael256_DCSAT_clauses

# Basic logging configuration for the entire module (adjust as needed)
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s: %(message)s",
    datefmt='%Y-%m-%d %H:%M:%S'
)


###############################################################################
# Base class for wrapping external solvers
###############################################################################
class external_solver:
    def __init__(self, cnf: CNF, solver_name: str = None, solver_log_name: str = None, threads: int = 1) -> None:
        self.solver_name = solver_name
        self.threads = threads
        self.solver_log_name = (
            solver_log_name
            if solver_log_name is not None
            else tempfile.NamedTemporaryFile(delete=False, suffix=".log").name
        )
        self.temp_cnf_file = tempfile.NamedTemporaryFile(delete=False, suffix=".cnf")
        self.preprocessor = self.preprocess_cnf(cnf)
        self.elapsed_time = 0.0
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")

    def __del__(self):
        try:
            os.remove(self.temp_cnf_file.name)
        except Exception as e:
            self.logger.warning(f"Error removing temporary CNF file: {e}")
        if self.solver_log_name is not None:
            try:
                os.remove(self.solver_log_name)
            except Exception as e:
                self.logger.warning(f"Error removing solver log file: {e}")

    def preprocess_cnf(self, cnf: CNF) -> CNF:
        preprocessor = Processor(bootstrap_with=cnf)
        preprocessed = preprocessor.process()
        self.pp_status = preprocessed.status
        if self.pp_status:
            preprocessed.to_file(self.temp_cnf_file.name)
        return preprocessor

    def solve(self) -> bool:
        raise NotImplementedError

    def time(self) -> float:
        return self.elapsed_time

    def get_model(self) -> List[int]:
        return self.get_satisfied_variables(self.solver_log_name)

    def check_satisfiability(self, file_name: str):
        with open(file_name, "r") as f:
            for line in f:
                if line.startswith("s "):
                    return "UN" not in line
        raise Exception("No satisfiability information found in the solver log file")

    def get_satisfied_variables(self, file_name: str) -> List[int]:
        v = []
        with open(file_name, "r") as f:
            for line in f:
                if line.startswith("v "):
                    v.extend(line.strip().split()[1:])
        model = list(map(int, v))[:-1]
        if model:
            return self.preprocessor.restore(model)
        else:
            raise Exception("No model found in the solver log file")


###############################################################################
# Mallob solver (distributed SAT solver using MPI)
###############################################################################
class Mallob(external_solver):
    def __init__(self, cnf: CNF, threads: int = 1, processes: int = 1, solver_log_name: str = None, hosts_setting=None) -> None:
        super().__init__(cnf, threads=threads, solver_log_name=solver_log_name, solver_name="mallob")
        self.processes = processes
        self.solver_dir = f"sat_solvers/{self.solver_name}"
        self.hosts_setting = hosts_setting
        self.setup_mallob()

    def __del__(self):
        try:
            os.remove(self.temp_cnf_file.name)
        except Exception as e:
            self.logger.warning(f"Error removing temporary CNF file in Mallob __del__: {e}")

    @staticmethod
    def check_directory(path: str) -> None:
        def mallob_build(path) -> None:
            if not os.path.exists(path):
                script_path = os.path.join(path, "build_mallob.sh")
                os.chmod(script_path, 0o755)
                subprocess.run(script_path, shell=True)
        if not os.path.exists(f"{path}/mallob"):
            mallob_build(f"{path}/mallob")

    def cleanup(self):
        subprocess.run("pkill -f mallob > /dev/null 2>&1", shell=True)

    def setup_mallob(self) -> None:
        self.mallob_options = (
            f"-mono={self.temp_cnf_file.name} -seed=110519 "
            f"-v=1 -t={self.threads} -max-lits-per-thread=100000000 "
            f"-buffered-imported-cls-generations=10 -clause-buffer-base-size=5000 -clause-buffer-discount=0.9 "
            f"-clause-filter-clear-interval=200 -strict-clause-length-limit=20 -strict-lbd-limit=20 -satsolver=kkkccl "
            f"-extmem-disk-dir={self.solver_dir}/tmp -processes-per-host=1 -regular-process-allocation=1 -sleep=1000 -trace-dir=/tmp -rpa=1 "
            f"-s2f={self.solver_log_name}"
        )
        self.build_dir = f"{self.solver_dir}/mallob/build"
        if not os.path.isdir(self.build_dir):
            raise FileNotFoundError(f"Directory {self.build_dir} does not exist or is not accessible.")
        hosts_config = self.hosts_setting or {f"{os.uname().nodename}": self.processes}
        self.hosts = [
            "--host",
            ",".join([f"{host}:{count}" for host, count in hosts_config.items()]),
            "-np",
            f"{sum(hosts_config.values())}",
        ]
        self.mpi_options = f"--use-hwthread-cpus --mca btl_tcp_if_include 192.168.0.0/24 -x MALLOC_CONF=thp:always -x LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libtbbmalloc.so -x RDMAV_FORK_SAFE=1".split()

    def solve(self) -> bool:
        if not self.pp_status:
            return False
        start = time.perf_counter()
        cmd = ["mpirun", "--use-hwthread-cpus", *self.mpi_options, *self.hosts, "mallob"] + self.mallob_options.split()
        result = subprocess.run(cmd, cwd=self.build_dir, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=os.environ.copy())
        if result.returncode != 0:
            self.logger.error("mpirun failed with return code %s", result.returncode)
            self.logger.error("Command: %s", " ".join(cmd))
            self.logger.error("STDOUT: %s", result.stdout)
            self.logger.error("STDERR: %s", result.stderr)
            raise RuntimeError(f"mpirun failed with return code {result.returncode}")
        self.elapsed_time = time.perf_counter() - start
        sat = self.check_satisfiability(self.solver_log_name)
        return sat


###############################################################################
# Painless solver
###############################################################################
class Painless(external_solver):
    def __init__(self, cnf: CNF, num_threads: int = 1, num_processes: int = 1, solver_log_name: str = None) -> None:
        super().__init__(cnf, solver_name="painless", threads=num_threads, solver_log_name=solver_log_name)
        self.solver_dir = f"sat_solvers/{self.solver_name}"
        self.num_processes = num_processes
        self.check_directory(self.solver_dir)
        self.set_painless_options()

    def check_directory(self, path: str) -> None:
        if not os.path.exists(path):
            os.makedirs(path)
        if not os.path.exists(f"{path}/painless"):
            self.painless_build()

    def painless_build(self) -> None:
        if not os.path.exists(f"{self.solver_dir}/{self.solver_name}"):
            script_path = os.path.join(self.solver_dir, "build_painless.sh")
            os.chmod(script_path, 0o755)
            subprocess.run(script_path, shell=True)

    def set_painless_options(self) -> None:
        self.painless_options = f"-v=0 -c={self.threads} -shr-strat=3 -shr-sleep=100000 -sbva-count=12 -ls-after-sbva=2 -sbva-timeout=1000 -dist=1"

    def solve(self) -> bool:
        if not self.pp_status:
            return False
        start = time.perf_counter()
        solver_path = os.path.join(self.solver_dir, "painless/build/release")
        if self.num_processes == 1:
            cmd = f"{os.path.join(solver_path, 'painless_release')} {self.painless_options} {self.temp_cnf_file.name} > {self.solver_log_name}"
            subprocess.run(cmd, shell=True)
        else:
            cmd = (
                f"cd {solver_path}; export OMPI_MCA_orte_abort_on_non_zero_status=0; "
                f"mpirun --use-hwthread-cpus -np {self.num_processes} painless_release {self.painless_options} -simple=1 -mallob=1 {self.temp_cnf_file.name} > {self.solver_log_name}"
            )
            subprocess.run(cmd, shell=True)
        self.elapsed_time = time.perf_counter() - start
        sat = self.check_satisfiability(self.solver_log_name)
        return sat


###############################################################################
# DC-SAT solver main class
###############################################################################
class DCSATSolver:
    def __init__(self, cipher: str, attack: str, start_rnd: int, end_rnd: int,
                 nof_boolean_cardinality: int, solver_name: str = "cd19",
                 num_threads: int = 1, num_processes: int = 1, dcp_result: dict = {},
                 debug: bool = False):
        self.debug = debug
        self.cipher = cipher
        self.attack = attack
        self.starting_round = start_rnd
        self.max_round = end_rnd
        self.nof_bool_cardinality = nof_boolean_cardinality
        self.solver_name = solver_name
        self.num_threads = num_threads
        self.nof_processes = num_processes
        self.time_accum = []
        self.dcp_result = dcp_result
        self.setup_cipher_settings()
        self.check_directory("log_dcsat")
        self.enc = self.get_encoding_type()
        self.log_name = os.path.join("log_dcsat", self.cipher, self.attack, f"DC-SAT_{self.enc}.txt")
        self.setup_logger()

    def setup_logger(self):
        self.logger = logging.getLogger(f"{self.cipher}_{self.attack}_DCSATSolver")
        self.logger.setLevel(logging.DEBUG if self.debug else logging.INFO)
        # Avoid adding duplicate handlers
        if not self.logger.handlers:
            os.makedirs(os.path.dirname(self.log_name), exist_ok=True)
            fh = logging.FileHandler(self.log_name)
            fh.setLevel(logging.DEBUG if self.debug else logging.INFO)
            ch = logging.StreamHandler()
            ch.setLevel(logging.DEBUG if self.debug else logging.INFO)
            formatter = logging.Formatter('[%(asctime)s] %(levelname)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
            fh.setFormatter(formatter)
            ch.setFormatter(formatter)
            self.logger.addHandler(fh)
            self.logger.addHandler(ch)

    def check_directory(self, path):
        for p in [path, os.path.join(path, self.cipher), os.path.join(path, self.cipher, self.attack, "log")]:
            if not os.path.exists(p):
                os.makedirs(p)

    def setup_cipher_settings(self):
        settings_map = {
            "AES": {
                "sboxes": 16,
                "msv_indicate": 1,
                "msv_weight": 7,
                "lsv_indicate": 6,
                "known_active_sbox": [None] + [1, 5, 9, 25, 26, 30, 34, 50, 51, 55],
            },
            "Rijndael256": {
                "sboxes": 32,
                "msv_indicate": 1,
                "msv_weight": 7,
                "lsv_indicate": 6,
                "known_active_sbox": [None] + [1, 5, 9, 25, 41, 50, 58, 65, 74, 85],
            },
            "Camellia": {
                "sboxes": 8,
                "msv_indicate": 1,
                "msv_weight": 7,
                "lsv_indicate": 6,
                "known_active_sbox": [None] + [0, 1, 2, 7, 9, 12, 14, 16, 20, 22, 24],
            },
            "ARIA": {
                "sboxes": 16,
                "msv_indicate": 1,
                "msv_weight": 7,
                "lsv_indicate": 6,
                "known_active_sbox": [None] + [1, 8, 9, 16, 17, 24, 25, 32, 33, 40, 41, 48],
            },
            "LED": {
                "sboxes": 16,
                "msv_indicate": 1 if self.attack == "Differential" else 2,
                "msv_weight": 3,
                "lsv_indicate": 2,
                "known_active_sbox": [None] + [1, 5, 9, 25, 26, 30, 34, 50, 51, 55, 59, 75, 76, 80, 84, 100],
            },
            "Midori": {
                "sboxes": 32,
                "msv_indicate": 1 if self.attack == "Differential" else 2,
                "msv_weight": 3,
                "lsv_indicate": 2,
                "known_active_sbox": [None] + [1, 4, 7, 16, 23, 30, 35, 38, 41, 50, 57, 62, 67, 72, 75, 84],
            },
        }
        settings = settings_map.get(self.cipher, None)
        if settings:
            self.nof_sbox = settings["sboxes"]
            self.ind_msv = settings["msv_indicate"]
            self.msv_wt = settings["msv_weight"]
            self.ind_lsv = settings["lsv_indicate"]
            self.known_AS = settings["known_active_sbox"]
        else:
            self.nof_sbox = None
            self.ind_msv = None
            self.msv_wt = None
            self.ind_lsv = None
            self.known_AS = None

    def get_cipher_clauses(self, num_rounds):
        cipher_clause_functions = {
            "AES": get_AES_DCSAT_clauses,
            "Rijndael256": get_Rijndael256_DCSAT_clauses,
            "LED": get_LED_DCSAT_clauses,
            "Camellia": get_Camellia_DCSAT_Differential_clauses,
            "ARIA": get_ARIA_DCSAT_Differential_clauses,
            "Midori": get_Midori128_DCSAT_clauses,
        }
        clause_function = cipher_clause_functions.get(self.cipher)
        if clause_function:
            if self.cipher in ["AES", "Camellia", "Rijndael256"]:
                return clause_function(num_rounds)
            else:
                return clause_function(num_rounds, self.attack)
        else:
            raise ValueError(f"Unsupported cipher: {self.cipher}")

    def determine_solution_space(self, dp_range, min_AS):
        return [
            (dp, i, j)
            for dp, i, j in product(dp_range, reversed(range(300)), range(min_AS, 300))
            if (self.ind_msv * i + j * self.ind_lsv) == dp and (i + j) >= min_AS and i <= j
        ]

    def get_DCPmax_k1(self, dp, min_AS=None):
        return max(
            j
            for i, j in product(reversed(range(300)), range(300))
            if (self.ind_msv * i + j * self.ind_lsv) == dp
            and i <= j
            and (self.cipher == "Camellia" or (i + j) >= min_AS)
        )

    def get_DCPmax_k0(self, dp, min_AS=None):
        return max(
            i
            for i, j in product(reversed(range(300)), range(300))
            if (self.ind_msv * i + j * self.ind_lsv) == dp
            and i <= j
            and (self.cipher == "Camellia" or (i + j) >= min_AS)
        )

    def matsui_divide_milp(self, target_dcp, k0_constraint, wt, wt_dash, AS, dcp_k1_max, k1_ex):
        def check_sage():
            try:
                import sage
                return True
            except ImportError:
                return False

        def solve_milp_with_alternative_library(k0_or_k1=0, maximize=True):
            from ortools.linear_solver import pywraplp
            if k0_or_k1 == 0 and k0_constraint == 0:
                return 0
            solver = pywraplp.Solver.CreateSolver("SCIP")
            k = [solver.IntVar(0, solver.infinity(), f"k{i}") for i in range(2)]
            solver.Add(self.ind_msv * k[0] + self.ind_lsv * k[1] <= idcp)
            solver.Add(k[0] <= k[1])
            solver.Add(AS <= k[1])
            solver.Add(wt_dash <= self.ind_msv * k[0] + self.ind_lsv * k[1])
            if self.attack == "Differential":
                solver.Add(k[0] <= k0_constraint)
            solver.Add(k[1] <= dcp_k1_max)
            solver.Add(k[1] <= k1_ex)
            objective = k[k0_or_k1]
            solver.Maximize(objective if maximize else -objective)
            status = solver.Solve()
            if status == pywraplp.Solver.OPTIMAL:
                return int(solver.Objective().Value())
            else:
                return None

        def solve_milp_with_sage(k0_or_k1=0, maximize=True):
            from sage.all import ZZ
            from sage.numerical.mip import MixedIntegerLinearProgram
            if k0_or_k1 == 0 and k0_constraint == 0:
                return 0
            p = MixedIntegerLinearProgram(maximization=maximize, solver="PPL")
            k = p.new_variable(integer=True, nonnegative=True)
            p.add_constraint(self.ind_msv * k[0] + self.ind_lsv * k[1] <= idcp)
            p.add_constraint(k[0] <= k[1])
            p.add_constraint(AS <= k[1])
            p.add_constraint(wt_dash <= self.ind_msv * k[0] + self.ind_lsv * k[1])
            if self.attack == "Differential":
                p.add_constraint(k[0] <= k0_constraint)
            p.add_constraint(k[1] <= dcp_k1_max)
            p.add_constraint(k[1] <= k1_ex)
            p.set_objective(k[k0_or_k1])
            try:
                return p.solve()
            except Exception as e:
                self.logger.error("MILP with sage failed: %s", e)
                return None

        idcp = target_dcp - wt
        results = (
            [solve_milp_with_sage(i, True) for i in [0, 1]]
            if check_sage()
            else [solve_milp_with_alternative_library(i, True) for i in [0, 1]]
        )
        if None in results:
            return None, None
        return map(int, results)

    def matsui_algorithm_clauses(self, cnf: CNF, round: int, nof_msv: int, nof_lsv: int,
                                  dcp_results: dict, ml_prob_var: Tuple[List[int], List[int]],
                                  objective_dp: int) -> CNF:
        msv, lsv = ml_prob_var
        result_dp = [self.ind_msv * val[0] + self.ind_lsv * val[1] for val in dcp_results.values()]
        start = max(round - len(result_dp), 1)
        AS_range = [dcp_results[i][1] for i in range(start, len(result_dp) + 1)]
        known_dp = result_dp[start - 1:]
        s = zip(range(start, round + 1), known_dp[::-1], known_dp, AS_range, AS_range[::-1])
        dcp_k1_max = (
            self.get_DCPmax_k1(objective_dp, self.known_AS[round])
            if self.cipher != "Camellia"
            else self.get_DCPmax_k1(objective_dp)
        )
        added_constraint_k0, added_constraint_k1 = [], []

        for i, wt, wt_dash, AS_min, AS_min_rev in s:
            k1_ex = nof_lsv - AS_min_rev
            max_k0, max_k1 = self.matsui_divide_milp(objective_dp, nof_msv, wt, wt_dash, AS_min, dcp_k1_max, k1_ex)
            if None in (max_k0, max_k1):
                self.logger.warning("MILP infeasible for round %s with dp %s, nof_msv %s, nof_lsv %s", i, objective_dp, nof_msv, nof_lsv)
                return None

            for j in range(2):
                vars_msv = msv[: i * self.nof_sbox] if j == 0 else msv[-(i * self.nof_sbox):]
                vars_lsv = lsv[: i * self.nof_sbox] if j == 0 else lsv[-(i * self.nof_sbox):]

                for max_k, vars_lst, added_constraint_lst, nof_vars in [
                    (max_k0, vars_msv, added_constraint_k0, nof_msv),
                    (max_k1, vars_lsv, added_constraint_k1, nof_lsv),
                ]:
                    if max_k < nof_vars:
                        added_constraint_lst.append(max_k)
                        cnf.extend(
                            CardEnc.atmost(
                                lits=vars_lst,
                                encoding=self.nof_bool_cardinality,
                                bound=max_k,
                                top_id=cnf.nv,
                            )
                        )
                    else:
                        added_constraint_lst.append(None)

        return cnf

    def run(self):
        self.logger.info("Starting DCSATSolver for %s cipher, %s attack", self.cipher, self.attack)
        self.logger.info("Cipher, Round, %sCP, Sec", 'D' if self.attack == 'Differential' else 'L')

        for current_round in range(self.starting_round, self.max_round + 1):
            round_time = 0
            solution_space = self.get_solution_space(current_round, self.dcp_result)
            clauses, msv, lsv, var_count = self.get_cipher_clauses(current_round)

            for dp, nof_msv, nof_lsv in solution_space[18:]:
                cnf = self.prepare_cnf(clauses, msv, lsv, nof_msv, nof_lsv)

                if current_round > 1 or self.cipher != "Midori":
                    cnf = self.matsui_algorithm_clauses(cnf, current_round, nof_msv, nof_lsv, self.dcp_result, (msv, lsv), dp)
                    if cnf is None:
                        self.logger.warning("MILP infeasible for dp %s, nof_msv %s, nof_lsv %s", dp, nof_msv, nof_lsv)
                        continue

                log_name = os.path.join(os.path.abspath("log_dcsat"),
                                        f"{self.cipher}/{self.attack}/log/{current_round}-R_{nof_msv}-{nof_lsv}_{'D' if self.attack == 'Differential' else 'L'}CP-{dp}_dcsat_{self.enc}.log")
                if self.solver_name == "mallob":
                    th = 32
                    hosts = {
                        "Sanders": int(256 / th),
                        "Noyce": int(160 / th),
                        "Milan": int(256 / th),
                        "Palermo": int(512 / th),
                        "Su": int(128 / th),
                    }
                    solver = Mallob(cnf, threads=th, processes=self.num_threads, hosts_setting=hosts, solver_log_name=log_name)
                elif self.solver_name.startswith("cd") or self.solver_name.startswith("cadical"):
                    solver = Solver(name=self.solver_name, bootstrap_with=cnf.clauses, use_timer=True)
                elif self.solver_name == "painless":
                    solver = Painless(cnf, num_processes=self.nof_processes, num_threads=self.num_threads, solver_log_name=log_name)
                else:
                    raise ValueError(f"Unsupported solver: {self.solver_name}")
                sat = solver.solve()
                elapsed = solver.time()
                round_time += elapsed

                if sat == "":
                    self.logger.error("Solver returned empty result.")
                    break

                self.log_result(current_round, nof_msv, nof_lsv, dp, sat, elapsed)

                if sat:
                    model = solver.get_model()
                    self.log_final_info(current_round, dp, round_time)
                    self.dcp_result.update({current_round: (nof_msv, nof_lsv)})
                    self.time_accum.append(round_time)
                    if self.debug and self.cipher == "AES":
                        print_solution(model, current_round, ".AES_solution_")
                    break

        self.logger.info("DCP Result: %s", self.dcp_result)

    def get_solution_space(self, r, dcp_result):
        if self.cipher == "Camellia":
            return self._get_camellia_solution_space(r, dcp_result)
        else:
            dp_range = [i for i in range(self.known_AS[r] * self.ind_lsv, self.known_AS[r] * self.msv_wt)]
            return self.determine_solution_space(dp_range, self.known_AS[r])

    def _get_camellia_solution_space(self, r, dcp_result):
        get_solspace = lambda previous_dcp, previous_AS: [
            (dp, i, j)
            for dp, i, j in product(range(previous_dcp + 1, 300), reversed(range(300)), range(previous_AS + 1, 300))
            if (self.ind_msv * i + j * self.ind_lsv) == dp and i <= j
        ]
        if r > 1:
            dp_range = [i for i in range(self.known_AS[r] * self.ind_lsv, self.known_AS[r] * self.msv_wt + 1)]
            return self.determine_solution_space(dp_range, self.known_AS[r])
        else:
            return [(0, 0, 0)]

    def get_encoding_type(self):
        encoding_types = {1: "seq", 6: "tot", 8: "kmt"}
        return encoding_types.get(self.nof_bool_cardinality, "none")

    def prepare_cnf(self, clauses, msv, lsv, nof_msv, nof_lsv):
        cnf = CNF(from_clauses=clauses)
        cnf.extend(CardEnc.atmost(lits=list(lsv), encoding=self.nof_bool_cardinality, bound=nof_lsv, top_id=cnf.nv))
        cnf.extend(CardEnc.atmost(lits=list(msv), encoding=self.nof_bool_cardinality, bound=nof_msv, top_id=cnf.nv))
        return cnf

    def log_result(self, r, nof_msv, nof_lsv, dp, sat, elapsed):
        self.logger.info("[%d-R] %s, msv: %2d, AS: %2d, %sCP-%d, %sSAT, %.1f sec",
                         r,
                         self.cipher,
                         nof_msv,
                         nof_lsv,
                         'D' if self.attack == 'Differential' else 'L',
                         dp,
                         'S' if sat else 'UN-S',
                         elapsed)

    def log_final_info(self, r, dcp, round_time):
        self.logger.info("[%s] %s, Round: %d, DCP: %s, Total Time: %.1f sec",
                         time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
                         self.cipher,
                         r,
                         dcp,
                         round_time)


###############################################################################
# Main
###############################################################################
if __name__ == "__main__":
    def str_to_dict(arg_string):
        try:
            return ast.literal_eval(arg_string)
        except ValueError:
            raise argparse.ArgumentTypeError("Invalid dictionary format")

    parser = argparse.ArgumentParser(description="DC-SAT Solver")
    parser.add_argument("-c", "--cipher", type=str, help="Cipher to solve", required=True)
    parser.add_argument("-a", "--attack", type=str, help="Differential or Linear", required=True)
    parser.add_argument("-r", "--start_round", type=int, help="Start round", required=True)
    parser.add_argument("-e", "--end_round", type=int, help="End round", required=True)
    parser.add_argument("-b", "--nof_boolean_cardinality", type=int,
                        help="Encoding number of PySAT boolean cardinality", default=1)
    parser.add_argument("-s", "--solver", help="Solver name", type=str, default="cd19")
    parser.add_argument("-p", "--processes", help="Number of processes", type=int, default=1)
    parser.add_argument("-t", "--num_threads", help="Number of threads", type=int, default=1)
    parser.add_argument("-d", "--dcp_result", help="DCP result", type=str_to_dict, default="{}")
    parser.add_argument("-v", "--debug", help="Debug mode", action="store_true", default=False)
    args = parser.parse_args()

    try: 
        solver = DCSATSolver(
            args.cipher,
            args.attack,
            args.start_round,
            args.end_round,
            args.nof_boolean_cardinality,
            solver_name=args.solver,
            num_processes=args.processes,
            num_threads=args.num_threads,
            dcp_result=args.dcp_result,
            debug=args.debug,
        )
        solver.run()
    except Exception as e:
        logging.getLogger(__name__).exception("DC-SAT Solver failed: %s", e)
        raise