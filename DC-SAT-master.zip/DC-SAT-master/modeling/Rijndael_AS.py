import codecs
import os
from itertools import chain
from typing import List

from pysat.formula import IDPool, CNF
from pysat.card import CardEnc
from pysat.solvers import Solver
from pysat.process import Processor

Block_Size = 256
Nof_Sbox = 32
Sbox_Size = 8
Prob_var_size = 1
Nof_Column = 8
Nof_Rows = 4

def get_espresso_result_cnf(espresso_result_file, vars, espresso_cnf_out=None):
    with open(espresso_result_file, 'r') as fileobj:
        espresso_output = fileobj.readlines()
    # Parse the output of ESPRESSO
    bd = len(vars)
    sat_clauses = []
    starting_point = 0
    end_point = 0
    for i in range(len(espresso_output)):
        if ".p" in espresso_output[i]:
            starting_point = i + 1
        if ".e" in espresso_output[i]:
            end_point = i
    for l in espresso_output[starting_point:end_point]:
        line = l[0:bd]
        orclause = []
        for i in range(bd):
            if line[i] == '0':
                orclause.append(vars[i])
            elif line[i] == '1':
                orclause.append(-vars[i])
        sat_clauses.append(orclause)
    if espresso_cnf_out != None:
        print(*sat_clauses, sep='\n', file=codecs.open(espresso_cnf_out, 'w', 'utf-8'))
    return sat_clauses

def gf_mult(i, o, times):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    return get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files/aes_gf_x{times}_espresso_result.txt"), i + o)

def shift_rows(state):
    data = [[state[i * 32 + j * 8 : i * 32 + j * 8 + 8] for j in range(Nof_Rows)] for i in range(Nof_Column)]
    data = [[data[j][i] for j in range(Nof_Column)] for i in range(Nof_Rows)]
    tmp = [
        data[0],
        data[1][1:] + data[1][:1],
        data[2][3:] + data[2][:3],
        data[3][4:] + data[3][:4]
    ]
    tmp_2 = [[tmp[j][i] for j in range(Nof_Rows)] for i in range(Nof_Column)]
    return tmp_2

class RijndaelVariables:
    def __init__(self, pool : IDPool, max_round):
        self.bits_per_state = Block_Size
        self.dp_var_size = Nof_Sbox * Prob_var_size
        self.s_in = [[pool.id() for _ in range(self.bits_per_state)] for _ in range(max_round + 1)]
        self.s_out = [[pool.id() for _ in range(self.bits_per_state)] for _ in range(max_round)]
        self.dp_var = [[pool.id() for _ in range(self.dp_var_size)] for _ in range(max_round)]
        self.gf_out_x2 = [[pool.id() for _ in range(self.bits_per_state)] for _ in range(max_round)]
        self.gf_out_x3 = [[pool.id() for _ in range(self.bits_per_state)] for _ in range(max_round)]

def initialize_variables(max_round):
    pool = IDPool()
    variables = RijndaelVariables(pool, max_round)
    variables.s_in.append([pool.id() for _ in range(variables.bits_per_state)])
    return pool, variables

def add_initial_clause(clauses : list):
    clauses.append(list(range(1, Block_Size + 1)))

def process_round(r, clauses, variables : RijndaelVariables):
    for byte_pos in range(Block_Size // Sbox_Size):
        vars = variables.s_in[r][byte_pos*Sbox_Size : byte_pos*Sbox_Size+Sbox_Size] + \
               variables.s_out[r][byte_pos*Sbox_Size : byte_pos*Sbox_Size+Sbox_Size] + \
               variables.dp_var[r][byte_pos*Prob_var_size : byte_pos*Prob_var_size+Prob_var_size]
        sbox_cnf = get_espresso_result_cnf(os.path.join(os.path.dirname(__file__), 'simplified_files/aes_AS_espresso-dmany_result.txt'), vars)
        clauses += sbox_cnf
    shifted = shift_rows(variables.s_out[r])
    for idx in range(Nof_Column):
        tmp_data = shifted[idx]
        tmp_gf_out_x2 = variables.gf_out_x2[r][idx*32: idx*32+32]
        tmp_gf_out_x2 = [tmp_gf_out_x2[i*8:i*8+8] for i in range(Nof_Rows)]
        tmp_gf_out_x3 = variables.gf_out_x3[r][idx*32: idx*32+32]
        tmp_gf_out_x3 = [tmp_gf_out_x3[i*8:i*8+8] for i in range(Nof_Rows)]
        for i in range(Nof_Rows):
            clauses += gf_mult(tmp_data[i], tmp_gf_out_x2[i], 2)
            clauses += gf_mult(tmp_data[i], tmp_gf_out_x3[i], 3)
        tmp_mc_out = variables.s_in[r+1][idx*32: idx*32+32]
        tmp_mc_out = [tmp_mc_out[i*8:i*8+8] for i in range(Nof_Rows)]
        for a, b, c, d, e in zip(tmp_gf_out_x2[0], tmp_gf_out_x3[1], tmp_data[2], tmp_data[3], tmp_mc_out[0]):
            clauses += get_espresso_result_cnf(os.path.join(os.path.dirname(__file__), 'simplified_files/4bit_xor_tt_esp.txt'), [a, b, c, d, e])
        for a, b, c, d, e in zip(tmp_data[0], tmp_gf_out_x2[1], tmp_gf_out_x3[2], tmp_data[3], tmp_mc_out[1]):
            clauses += get_espresso_result_cnf(os.path.join(os.path.dirname(__file__), 'simplified_files/4bit_xor_tt_esp.txt'), [a, b, c, d, e])
        for a, b, c, d, e in zip(tmp_data[0], tmp_data[1], tmp_gf_out_x2[2], tmp_gf_out_x3[3], tmp_mc_out[2]):
            clauses += get_espresso_result_cnf(os.path.join(os.path.dirname(__file__), 'simplified_files/4bit_xor_tt_esp.txt'), [a, b, c, d, e])
        for a, b, c, d, e in zip(tmp_gf_out_x3[0], tmp_data[1], tmp_data[2], tmp_gf_out_x2[3], tmp_mc_out[3]):
            clauses += get_espresso_result_cnf(os.path.join(os.path.dirname(__file__), 'simplified_files/4bit_xor_tt_esp.txt'), [a, b, c, d, e])

def get_Rijndael_DP_clauses(max_round):
    pool, variables = initialize_variables(max_round)
    clauses = []
    add_initial_clause(clauses)
    for r in range(max_round):
        process_round(r, clauses, variables)
    return (clauses, variables.dp_var, pool.top)

def generic_matsui_algorithm(cnf: CNF, round: int, result_dp: List[int], dp_var: List[List[int]], objective_dp: int) -> CNF:
    for i, wt in zip(range(1, round + 1), reversed(result_dp)):
        idp = objective_dp - wt
        for j in range(2):
            selected_vars = dp_var[:i] if j == 0 else dp_var[-i:]
            objective_func = CardEnc.atmost(lits=list(chain.from_iterable(selected_vars)), encoding=6, bound=idp, top_id=cnf.nv)
            cnf.extend(objective_func)
    return cnf

def main():
    print("AES min#AS Search")
    num_of_AS = 1
    result = []
    for r in range(1,15):
        clauses, as_var, var_count = get_Rijndael_DP_clauses(r)
        sat = False
        while sat==False:
            cnf = CNF(from_clauses=clauses)
            bcc = CardEnc.atmost(lits=list(chain.from_iterable(as_var)), encoding=6, bound=num_of_AS, top_id=var_count)
            cnf.extend(bcc.clauses)
            if r > 1:
                cnf = generic_matsui_algorithm(cnf, r, result, as_var, num_of_AS)
            with Solver(name='cd19', bootstrap_with=cnf, use_timer=True) as solver:
                sat = solver.solve()
                end = solver.time()
                print(f'AES {r}-R, AS-{num_of_AS}, {"S" if sat else "UN-S"}AT, {end:.1f}[sec]')
                num_of_AS += 1
                if sat: 
                    print("")
                    result.append(num_of_AS-1)
                    break

if __name__ == '__main__':
    main()