from util.converter import get_espresso_result_cnf
from pysat.formula import IDPool
import os

script_dir = os.path.dirname(os.path.abspath(__file__))

def get_Camellia_DCSAT_Differential_clauses(max_round):
    def prepare_variables(max_round : int, id_pool : IDPool):
        nof_vars = 2
        clauses = []
        s_in = []
        s_out = []
        dp_var = []
        p_out = []
        initial_right = [id_pool.id() for _ in range(64)]
        for r in range(max_round):
            s_in.append([id_pool.id() for _ in range(64)])
            s_out.append([id_pool.id() for _ in range(64)])
            dp_var.append([id_pool.id() for _ in range(nof_vars * 8)])
            p_out.append([id_pool.id() for _ in range(64)])
        s_in.append([id_pool.id() for _ in range(64)])
        final_R = [id_pool.id() for _ in range(64)]
        return clauses, s_in, s_out, dp_var, p_out, initial_right, final_R

    def __F_func(clauses, s_in, s_out, dp_var, p_out, R, next_sin):
        def add_sbox_clauses(clauses, s_in, s_out, dp_var):
            nof_vars = 2
            for byte_pos, s_name in enumerate(["s1", "s2", "s3", "s4", "s2", "s3", "s4", "s1"]):
                vars = list(s_in[byte_pos*8: byte_pos*8+8] + s_out[byte_pos*8: byte_pos*8+8] + dp_var[byte_pos*nof_vars: byte_pos*nof_vars+nof_vars])
                cnf_path = os.path.join(script_dir, f'simplified_files/Camellia_{s_name}_espresso_result.txt')
                sbox_cnf = get_espresso_result_cnf(cnf_path, vars)
                clauses += sbox_cnf
            return clauses

        def add_p_clauses(clauses, s_out, p_out):
            p = [
                [0,1,1,1,1,0,0,1],
                [1,0,1,1,1,1,0,0],
                [1,1,0,1,0,1,1,0],
                [1,1,1,0,0,0,1,1],
                [0,1,1,1,1,1,1,0],
                [1,0,1,1,0,1,1,1],
                [1,1,0,1,1,0,1,1],
                [1,1,1,0,1,1,0,1],
            ]
            for byte_pos, _p in enumerate(reversed(p)):
                t = [s_out[b*8: b*8+8] for b, f in enumerate(reversed(_p)) if f == 1] + [p_out[byte_pos*8: byte_pos*8+8]]
                for a in zip(*t):
                    clauses += get_espresso_result_cnf(
                        os.path.join(script_dir, f"simplified_files/{len(t)-1}bit_xor_tt_esp.txt"), a
                    )
            return clauses

        def add_f_xor_r_clauses(clauses, p_out, R, next_sin):
            for a, b, c in zip(p_out, R, next_sin):
                clauses += [[-a, -b, -c], [a, b, -c], [a, -b, c], [-a, b, c]]
            return clauses

        clauses = add_sbox_clauses(clauses, s_in, s_out, dp_var)
        clauses = add_p_clauses(clauses, s_out, p_out)
        clauses = add_f_xor_r_clauses(clauses, p_out, R, next_sin)
        return clauses, s_in

    id_pool = IDPool()
    clauses, s_in, s_out, dp_var, p_out, initial_right, final_R = prepare_variables(max_round, id_pool)

    # ------------------ avoid zero difference ------------------
    clauses.append([_ for _ in range(1,128+1)]) 

    #  ------------------ Round Function ------------------
    R = initial_right
    for r in range(max_round):
        #  ------------------ F function ------------------
        clauses, R = __F_func(clauses, s_in[r], s_out[r], dp_var[r], p_out[r], R, s_in[r + 1])

    #  ------------------ Final process ------------------
    for a, b in zip(s_in[max_round - 1], final_R):
        clauses += [[a, -b], [-a, b]]

    msv = [item for sublist in dp_var for item in sublist[::2]]
    lsv = [item for sublist in dp_var for item in sublist][1::2]
    return (clauses, msv, lsv, id_pool.top)
