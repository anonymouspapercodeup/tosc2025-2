import os
from util.converter import get_espresso_result_cnf

def get_Midori128_redundant_clauses(max_round):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    def SSbi(x, i, s_out, dp_var):
        if i == 0:
            n0 = list([x[4], x[1], x[6], x[3]] + [s_out[4], s_out[1], s_out[6], s_out[3]] + dp_var[:3])
            n1 = list([x[0], x[5], x[2], x[7]] + [s_out[0], s_out[5], s_out[2], s_out[7]] + dp_var[3:])
        elif i == 1:
            n0 = list([x[1], x[6], x[7], x[0]] + [s_out[1], s_out[6], s_out[7], s_out[0]] + dp_var[:3])
            n1 = list([x[5], x[2], x[3], x[4]] + [s_out[5], s_out[2], s_out[3], s_out[4]] + dp_var[3:])
        elif i == 2:
            n0 = list([x[2], x[3], x[4], x[1]] + [s_out[2], s_out[3], s_out[4], s_out[1]] + dp_var[:3])
            n1 = list([x[6], x[7], x[0], x[5]] + [s_out[6], s_out[7], s_out[0], s_out[5]] + dp_var[3:])
        elif i == 3:
            n0 = list([x[7], x[4], x[1], x[2]] + [s_out[7], s_out[4], s_out[1], s_out[2]] + dp_var[:3])
            n1 = list([x[3], x[0], x[5], x[6]] + [s_out[3], s_out[0], s_out[5], s_out[6]] + dp_var[3:])
        clauses = get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files//Midori128_sbox_redundant_espresso_result.txt"), n0)
        clauses += get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files//Midori128_sbox_redundant_espresso_result.txt"), n1)
        return clauses
    def shuffle_cell(state):
        from itertools import chain
        # Midori64 shufflecell
        var = state
        var_sh = [var[i:i+8] for i in range(0,128,8)]
        var_sh = [var_sh[0], var_sh[10], var_sh[5], var_sh[15], var_sh[14], var_sh[4], var_sh[11], var_sh[1], var_sh[9], var_sh[3], var_sh[12], var_sh[6], var_sh[7], var_sh[13], var_sh[2], var_sh[8]]
        var_sh = list(chain.from_iterable(var_sh))
        return var_sh
    var_count = 1
    clauses = []
    # avoid ALL zero diff = ALL TRUE
    clauses.append([_ for _ in range(1, 129)])
    s_in = []
    s_out = []
    dp_var = []
    for r in range(max_round):
        # S-Box
        s_in += [[_ for _ in range(var_count, var_count + 128)]]
        var_count += 128
        s_out += [[_ for _ in range(var_count, var_count + 128)]]
        var_count += 128
        dp_var.append([_ for _ in range(var_count, var_count + (32*3))])
        var_count += 32*3
    s_in += [[_ for _ in range(var_count, var_count + 128)]]
    var_count += 128
    for r in range(max_round):
        # S-Box
        for byte_pos in range(16):
            clauses += SSbi(s_in[r][byte_pos*8:byte_pos*8+8], byte_pos%4, s_out[r][byte_pos*8:byte_pos*8+8], dp_var[r][byte_pos*6:byte_pos*6+6])
        # permutation
        shuffled = shuffle_cell(s_out[r])
        # MixColumn
        mixcolumn_idx = [[1,2,3],[0,2,3],[0,1,3],[0,1,2]]
        mc_out = s_in[r+1]
        word_size, unit_size = 32,8
        for block in range(4):
            for row in range(4):
                idx = mixcolumn_idx[row]
                for bit_pos in range(8):
                    t = [shuffled[word_size*block + unit_size*idx[0] + bit_pos]] + [shuffled[word_size*block + unit_size*idx[1] + bit_pos]] + [shuffled[word_size*block + unit_size*idx[2] + bit_pos]] + [mc_out[word_size*block + unit_size*row + bit_pos]]
                    e = get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files/3bit_xor_tt_esp.txt"), t)
                    a,b,c,d = t
                    f = [[a,-b,-c,-d],[-a,b,-c,-d],[-a,-b,c,-d],[a,b,c,-d],[-a,-b,-c,d],[a,b,-c,d],[a,-b,c,d],[-a,b,c,d]]
                    clauses += f
    return (clauses, dp_var, var_count)
