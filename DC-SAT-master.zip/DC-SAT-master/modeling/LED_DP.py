import os
from itertools import chain
from util.converter import get_espresso_result_cnf

def get_LED_redundant_clauses(max_round):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    def shift_rows(state):
        data = [[state[i*16 + j*4 : i*16 + j*4 + 4] for j in range(4)] for i in range(4)]
        data = [[data[j][i] for j in range(4)] for i in range(4)]
        tmp = [
            data[0],
            data[1][1:] + data[1][:1],
            data[2][2:] + data[2][:2],
            data[3][3:] + data[3][:3]
        ]
        return tmp
    mtx = [
        [4,1,2,2],
        [8,6,5,6],
        [0xb,0xe,0xa,9],
        [2,2,0xf,0xb]
        ]
    var_count = 1
    clauses = []
    s_in = []
    s_out = []
    dp_var = []
    gf_out = []
    for r in range(max_round):
        s_in += [[_ for _ in range(var_count, var_count+64)]]
        var_count += 64
        s_out += [[_ for _ in range(var_count, var_count+64)]]
        var_count += 64
        dp_var += [[_ for _ in range(var_count, var_count+(16*3))]]
        var_count += 16*3
        gf_out += [[_ for _ in range(var_count, var_count+(64*4))]]
        var_count += 64*4
    s_in += [[_ for _ in range(var_count, var_count + 64)]]
    var_count += 64
    clauses.append([_ for _ in range(1, 65)])
    for r in range(max_round):
        # sub cell
        for nibble_pos in range(16):
            vars = list(s_in[r][nibble_pos*4 : nibble_pos*4+4] + s_out[r][nibble_pos*4 : nibble_pos*4+4] + dp_var[r][nibble_pos*3 : nibble_pos*3+3])
            clauses += get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files//LED_sbox_redundant_espresso_result.txt"), vars)
        # shift row
        shifted = shift_rows(s_out[r])
        # mix columns
        for idx in range(4):
            tmp_data = shifted[idx]
            # preliminary of Galois multiplication in GF(16)
            tmp_gf_out = [gf_out[r][idx*64:idx*64+64][i*4:i*4+4] for i in range(16)]
            for nibble,gm,mtx_elm in zip(tmp_data*4, tmp_gf_out, chain.from_iterable(mtx)):
                if mtx_elm != 1:
                    clauses += get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files/LED_gf_gf4x{mtx_elm:02x}-13_espresso_result.txt"), nibble + gm)
                else:
                    for a,b in zip(nibble,gm):
                        clauses += [[a,-b],[-a,b]]
            # matxrix multiplication
            tmp_gf_out = [tmp_gf_out[i*4:i*4+4] for i in range(4)]
            tmp_mc_out = [s_in[r+1][idx*16: idx*16+16][i*4:i*4+4] for i in range(4)]
            for mc_in, mc_out in zip(tmp_gf_out, tmp_mc_out):
                for a,b,c,d,e in zip(*mc_in, mc_out):
                    clauses += get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files//4bit_xor_tt_esp.txt"), [a,b,c,d,e])
    return (clauses, dp_var, var_count)
