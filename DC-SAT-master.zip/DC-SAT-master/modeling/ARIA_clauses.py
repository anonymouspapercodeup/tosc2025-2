from itertools import chain
import os
from util.converter import get_espresso_result_cnf
from pysat.formula import IDPool

script_dir = os.path.dirname(os.path.abspath(__file__))

def get_ARIA_DCSAT_Differential_clauses(max_round, attack):
    def initialize_variables(max_round, id_pool):
        s_in = []
        s_out = []
        dp_var = []
        for r in range(max_round):
            s_in.append([id_pool.id() for _ in range(128)])
            s_out.append([id_pool.id() for _ in range(128)])
            dp_var.append([id_pool.id() for _ in range(2 * 16)])
        s_in.append([id_pool.id() for _ in range(128)])
        return s_in, s_out, dp_var

    def generate_clauses(max_round, s_in, s_out, dp_var, p):
        clauses = []
        clauses.append([_ for _ in range(1,129)])
        for r in range(max_round):
            sboxes = ["s1", "s2", "s3", "s4"] * 4 if (r + 1) % 2 == 0 else ["s3", "s4", "s1", "s2"] * 4
            for byte_pos, s_name in enumerate(sboxes):
                vars = list(s_in[r][byte_pos * 8: byte_pos * 8 + 8] + s_out[r][byte_pos * 8: byte_pos * 8 + 8] + dp_var[r][byte_pos * 2: byte_pos * 2 + 2])
                cnf_path = os.path.join(script_dir, f'simplified_files/ARIA_{s_name}_espresso_result.txt')
                sbox_cnf = get_espresso_result_cnf(cnf_path, vars)
                clauses += sbox_cnf
            for byte_pos, _p in enumerate(p):
                t = [s_out[r][b * 8: b * 8 + 8] for b, f in enumerate(_p) if f == 1] + [s_in[r + 1][byte_pos * 8: byte_pos * 8 + 8]]
                for a in zip(*t):
                    clauses += get_espresso_result_cnf(os.path.join(script_dir, f'simplified_files/7bit_xor_tt_esp.txt'), a)
        return clauses

    p = [[0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0],
         [0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1],
         [0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1],
         [1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0],
         [1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1],
         [0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1],
         [1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0],
         [0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0],
         [1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1],
         [1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0],
         [0, 0, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1],
         [0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0],
         [0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0],
         [1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0],
         [1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0],
         [0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1]]

    id_pool = IDPool()
    s_in, s_out, dp_var = initialize_variables(max_round, id_pool)
    clauses = generate_clauses(max_round, s_in, s_out, dp_var, p)

    msv = list(chain.from_iterable(dp_var))
    msv = [msv[d] for d in range(0, len(msv), 2)]
    lsv = list(chain.from_iterable(dp_var))
    lsv = [lsv[d] for d in range(1, len(lsv), 2)]

    return (clauses, msv, lsv, id_pool.top)