import os

from util.converter import get_espresso_result_cnf

def get_ARIA_redundant_clauses(max_round):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    p =  [[0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0],
          [0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1],
          [0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1],
          [1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0],
          [1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1],
          [0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1],
          [1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0],
          [0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0],
          [1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1],
          [1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0],
          [0, 0, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1],
          [0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0],
          [0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0],
          [1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0],
          [1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0],
          [0, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1]]
    var_count = 1
    clauses = []
    s_in = []
    s_out = []
    dp_var = []
    for r in range(max_round):
        s_in += [[_ for _ in range(var_count, var_count+128)]]
        var_count += 128
        s_out += [[_ for _ in range(var_count, var_count+128)]]
        var_count += 128
        dp_var += [[_ for _ in range(var_count, var_count+(7*16))]]
        var_count += 7*16
    s_in += [[_ for _ in range(var_count, var_count + 128)]]
    var_count += 128
    clauses.append([_ for _ in range(1, 129)])
    for r in range(max_round):
        sboxes = ["s1", "s2", "s3", "s4"]*4  if r+1 % 2 == 0 else ["s3", "s4", "s1", "s2"]*4
        for byte_pos,s_name in enumerate(sboxes):
            vars = list(s_in[r][byte_pos*8: byte_pos*8+8] + s_out[r][byte_pos*8: byte_pos*8+8] + dp_var[r][byte_pos*7: byte_pos*7+7])
            sbox_cnf = get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files/ARIA_{s_name}_redundant_espresso_result.txt"), vars)
            clauses += sbox_cnf
        for byte_pos,_p in enumerate(p):
            t = [s_out[r][b*8: b*8+8] for b,f in enumerate(_p) if f==1] + [s_in[r+1][byte_pos*8: byte_pos*8+8]]
            for a in zip(*t):
                clauses += get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files/7bit_xor_tt_esp.txt"), a)
    return (clauses, dp_var, var_count)