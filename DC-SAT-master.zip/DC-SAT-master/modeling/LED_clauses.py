from itertools import chain
import os
from util.converter import get_espresso_result_cnf
from pysat.formula import IDPool

def get_LED_DCSAT_clauses(max_round, isDifferential=True):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    id_pool = IDPool()

    def generate_variables(prefix, round_num, count):
        return [id_pool.id(f"{prefix}_{round_num}_{i}") for i in range(count)]

    def shift_rows(state):
        data = [[state[i*16 + j*4 : i*16 + j*4 + 4] for j in range(4)] for i in range(4)]
        data = [[data[j][i] for j in range(4)] for i in range(4)]
        tmp = [
            data[0],
            data[1][1:] + data[1][:1],
            data[2][2:] + data[2][:2],
            data[3][3:] + data[3][:3]
        ]
        return tmp

    def initialize_variables(max_round, pool):
        clauses = [[_ for _ in range(1,64+1)]]
        s_in, s_out, dp_var, gf_out = [], [], [], []
        for r in range(max_round):
            s_in.append(generate_variables('s_in', r, 64))
            s_out.append(generate_variables("s_out", r, 64))
            dp_var.append(generate_variables('dp_var', r, 16*2))
            gf_out.append(generate_variables("gf_out", r, 64*4))
        s_in.append(generate_variables("s_in", max_round, 64))
        return clauses, s_in, s_out, dp_var, gf_out

    def get_mtx(isDifferential):
        return [
            [4, 1, 2, 2],
            [8, 6, 5, 6],
            [0xb, 0xe, 0xa, 9],
            [2, 2, 0xf, 0xb]
        ] if isDifferential else [
            [4, 8, 0xb, 2],
            [1, 6, 0xe, 2],
            [2, 5, 0xa, 0xf],
            [2, 6, 9, 0xb]
        ]

    def process_sub_cell(clauses, s_in, s_out, dp_var, r, isDifferential):
        for nibble_pos in range(16):
            vars = list(s_in[r][nibble_pos*4 : nibble_pos*4+4] + s_out[r][nibble_pos*4 : nibble_pos*4+4] + dp_var[r][nibble_pos*2 : nibble_pos*2+2])
            clauses += get_espresso_result_cnf(os.path.join(script_dir, f'simplified_files/LED_{"Differential" if isDifferential else "Linear"}_espresso_result.txt'), vars)

    def process_mix_columns(clauses, shifted, s_in, gf_out, r, idx, mtx, isDifferential):
        tmp_data = shifted[idx] if isDifferential else [s_in[r+1][idx*16: idx*16+16][i*4:i*4+4] for i in range(4)]
        tmp_mc_out = [s_in[r+1][idx*16: idx*16+16][i*4:i*4+4] for i in range(4)] if isDifferential else shifted[idx]
        tmp_gf_out = [gf_out[r][idx*64:idx*64+64][i*4:i*4+4] for i in range(16)]

        for nibble, gm, mtx_elm in zip(tmp_data*4, tmp_gf_out, chain.from_iterable(mtx)):
            if mtx_elm != 1:
                clauses += get_espresso_result_cnf(os.path.join(script_dir, f'simplified_files/LED_gf_gf4x{mtx_elm:02x}-13_espresso_result.txt'), nibble + gm)
            else:
                for a, b in zip(nibble, gm):
                    clauses += [[a, -b], [-a, b]]

        tmp_gf_out = [tmp_gf_out[i*4:i*4+4] for i in range(4)]
        for mc_in, mc_out in zip(tmp_gf_out, tmp_mc_out):
            for a, b, c, d, e in zip(*mc_in, mc_out):
                clauses += get_espresso_result_cnf(os.path.join(script_dir, f'simplified_files/4bit_xor_tt_esp.txt'), [a, b, c, d, e])

    id_pool = IDPool()
    mtx = get_mtx(isDifferential)
    clauses, s_in, s_out, dp_var, gf_out = initialize_variables(max_round, id_pool)

    for r in range(max_round):
        process_sub_cell(clauses, s_in, s_out, dp_var, r, isDifferential)
        shifted = shift_rows(s_out[r])
        for idx in range(4):
            process_mix_columns(clauses, shifted, s_in, gf_out, r, idx, mtx, isDifferential)

    msv = [item for sublist in dp_var for item in sublist[::2]]
    lsv = [item for sublist in dp_var for item in sublist][1::2]
    return (clauses, msv, lsv, id_pool.top)
