import os

from util.converter import get_espresso_result_cnf

def get_Camellia_DP_clauses(max_round):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    def __F_func(clauses,s_in,s_out,dp_var,p_out,R,next_sin):
        p = [
            [0,1,1,1,1,0,0,1],
            [1,0,1,1,1,1,0,0],
            [1,1,0,1,0,1,1,0],
            [1,1,1,0,0,0,1,1],
            [0,1,1,1,1,1,1,0],
            [1,0,1,1,0,1,1,1],
            [1,1,0,1,1,0,1,1],
            [1,1,1,0,1,1,0,1],
        ]
        for byte_pos,s_name in enumerate(["s1", "s2", "s3", "s4", "s2", "s3", "s4", "s1"]):
            vars = list(s_in[byte_pos*8: byte_pos*8+8] + s_out[byte_pos*8: byte_pos*8+8] + dp_var[byte_pos*7: byte_pos*7+7])
            sbox_cnf = get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files/Camellia_{s_name}_redundant_espresso_result.txt"), vars)
            clauses += sbox_cnf
        for byte_pos,_p in enumerate(reversed(p)):
            t = [s_out[b*8: b*8+8] for b,f in enumerate(reversed(_p)) if f==1] + [p_out[byte_pos*8: byte_pos*8+8]]
            for a in zip(*t):
                clauses += get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files/{len(t)-1}bit_xor_tt_esp.txt"), a)
        for a,b,c in zip(p_out, R, next_sin):
            clauses += [[-a,-b,-c],[a,b,-c],[a,-b,c],[-a,b,c]]
        return clauses,s_in
    var_count = 1
    clauses = []
    s_in = []
    s_out = []
    dp_var = []
    p_out = []
    initial_right = [_ for _ in range(var_count, var_count+64)]
    var_count += 64
    for r in range(max_round):
        s_in += [[_ for _ in range(var_count, var_count+64)]]
        var_count += 64
        s_out += [[_ for _ in range(var_count, var_count+64)]]
        var_count += 64
        dp_var += [[_ for _ in range(var_count, var_count+(7*8))]]
        var_count += 7*8
        p_out += [[_ for _ in range(var_count, var_count+64)]]
        var_count += 64
    s_in += [[_ for _ in range(var_count, var_count + 64)]]
    var_count += 64
    final_R = [_ for _ in range(var_count, var_count+64)]
    var_count += 64
    clauses.append([_ for _ in range(1, 129)]) # avoid zero difference
    R = initial_right
    for r in range(max_round):
        clauses,R = __F_func(clauses,s_in[r],s_out[r],dp_var[r],p_out[r],R,s_in[r+1])
    for a,b in zip(s_in[max_round-1], final_R):
            clauses += [[a,-b],[-a,b]]
    return (clauses, dp_var, var_count)
