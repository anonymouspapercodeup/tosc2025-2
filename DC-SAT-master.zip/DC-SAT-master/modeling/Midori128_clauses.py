from itertools import chain
import os
from util.converter import get_espresso_result_cnf
from pysat.formula import IDPool

def get_Midori128_DCSAT_clauses(max_round, isDifferential=True):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    id_pool = IDPool()

    def generate_variables(prefix, round_num, count):
        return [id_pool.id(f'{prefix}_{round_num}_{i}') for i in range(count)]

    def initialize_variables(max_round):
        clauses = [[i for i in range(1, 129)]]
        s_in, s_out, dp_var = [], [], []

        for r in range(max_round):
            s_in.append(generate_variables('s_in', r, 128))
            s_out.append(generate_variables('s_out', r, 128))
            dp_var.append(generate_variables('dp_var', r, 64))

        s_in.append(generate_variables('s_in', max_round, 128))

        return clauses, s_in, s_out, dp_var

    def SSbi(x, i, s_out, dp_var):
        n0, n1 = [], []
        if i == 0:
            n0 = [x[4], x[1], x[6], x[3], s_out[4], s_out[1], s_out[6], s_out[3], *dp_var[:2]]
            n1 = [x[0], x[5], x[2], x[7], s_out[0], s_out[5], s_out[2], s_out[7], *dp_var[2:]]
        elif i == 1:
            n0 = [x[1], x[6], x[7], x[0], s_out[1], s_out[6], s_out[7], s_out[0], *dp_var[:2]]
            n1 = [x[5], x[2], x[3], x[4], s_out[5], s_out[2], s_out[3], s_out[4], *dp_var[2:]]
        elif i == 2:
            n0 = [x[2], x[3], x[4], x[1], s_out[2], s_out[3], s_out[4], s_out[1], *dp_var[:2]]
            n1 = [x[6], x[7], x[0], x[5], s_out[6], s_out[7], s_out[0], s_out[5], *dp_var[2:]]
        elif i == 3:
            n0 = [x[7], x[4], x[1], x[2], s_out[7], s_out[4], s_out[1], s_out[2], *dp_var[:2]]
            n1 = [x[3], x[0], x[5], x[6], s_out[3], s_out[0], s_out[5], s_out[6], *dp_var[2:]]
        
        sbox_cnf = os.path.join(script_dir, f'simplified_files/Midori128_{"Differential" if isDifferential else "Linear"}_espresso_result.txt')
        clauses = get_espresso_result_cnf(sbox_cnf, n0)
        clauses += get_espresso_result_cnf(sbox_cnf, n1)
        return clauses

    def shuffle_cell(state):
        var_sh = [state[i:i+8] for i in range(0, 128, 8)]
        var_sh = [var_sh[0], var_sh[10], var_sh[5], var_sh[15], var_sh[14], var_sh[4], var_sh[11], var_sh[1], var_sh[9], var_sh[3], var_sh[12], var_sh[6], var_sh[7], var_sh[13], var_sh[2], var_sh[8]]
        return list(chain.from_iterable(var_sh))

    clauses, s_in, s_out, dp_var = initialize_variables(max_round)

    for r in range(max_round):
        for byte_pos in range(16):
            clauses += SSbi(s_in[r][byte_pos*8:byte_pos*8+8], byte_pos % 4, s_out[r][byte_pos*8:byte_pos*8+8], dp_var[r][byte_pos*4:byte_pos*4+4])
        
        shuffled = shuffle_cell(s_out[r]) if isDifferential else s_in[r+1]
        word_size, unit_size = 32, 8
        mixcolumn_idx = [[1, 2, 3], [0, 2, 3], [0, 1, 3], [0, 1, 2]]
        mc_out = s_in[r+1] if isDifferential else shuffle_cell(s_out[r])

        for block in range(4):
            for row in range(4):
                idx = mixcolumn_idx[row]
                for bit_pos in range(8):
                    t = [shuffled[word_size*block + unit_size*idx[0] + bit_pos], shuffled[word_size*block + unit_size*idx[1] + bit_pos], shuffled[word_size*block + unit_size*idx[2] + bit_pos], mc_out[word_size*block + unit_size*row + bit_pos]]
                    clauses += get_espresso_result_cnf(os.path.join(script_dir, f'simplified_files/3bit_xor_tt_esp.txt'), t)

    msv = [item for sublist in dp_var for item in sublist[::2]]
    lsv = [item for sublist in dp_var for item in sublist[1::2]]
    return (clauses, msv, lsv, id_pool.top)
