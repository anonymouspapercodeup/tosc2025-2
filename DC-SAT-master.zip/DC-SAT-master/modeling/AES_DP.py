import os

from util.converter import get_espresso_result_cnf

def gf_mult(i, o, times):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    return get_espresso_result_cnf(os.path.join(script_dir, f"simplified_files/aes_gf_x{times}_espresso_result.txt"), i + o)

def shift_rows(state):
    data = [[state[i * 32 + j * 8 : i * 32 + j * 8 + 8] for j in range(4)] for i in range(4)]
    data = [[data[j][i] for j in range(4)] for i in range(4)]
    tmp = [
        data[0],
        data[1][1:] + data[1][:1],
        data[2][2:] + data[2][:2],
        data[3][3:] + data[3][:3]
    ]
    tmp_2 = [[tmp[j][i] for j in range(4)] for i in range(4)]
    return tmp_2

def get_AES_DP_clauses(max_round):
    var_count = 1
    clauses = []
    s_in = []
    s_out = []
    dp_var = []
    gf_out_x2 = []
    gf_out_x3 = []
    for r in range(max_round):
        s_in += [[_ for _ in range(var_count, var_count+128)]]
        var_count += 128
        s_out += [[_ for _ in range(var_count, var_count+128)]]
        var_count += 128
        dp_var += [[_ for _ in range(var_count, var_count+(16*7))]]
        var_count += 16*7
        gf_out_x2 += [[_ for _ in range(var_count, var_count+128)]]
        var_count += 128
        gf_out_x3 += [[_ for _ in range(var_count, var_count+128)]]
        var_count += 128
    s_in += [[_ for _ in range(var_count, var_count + 128)]]
    var_count += 128
    clauses.append([_ for _ in range(1, 129)])
    for r in range(max_round):
        for byte_pos in range(16):
            vars = list(s_in[r][byte_pos*8 : byte_pos*8+8] + s_out[r][byte_pos*8 : byte_pos*8+8] + dp_var[r][byte_pos*7 : byte_pos*7+7])
            sbox_cnf = get_espresso_result_cnf(os.path.join(os.path.dirname(__file__), 'simplified_files/aes_prob_sbox_espresso_result.txt'), vars)
            clauses += sbox_cnf
        shifted = shift_rows(s_out[r])
        for idx in range(4):
            tmp_data = shifted[idx]
            tmp_gf_out_x2 = gf_out_x2[r][idx*32: idx*32+32]
            tmp_gf_out_x2 = [tmp_gf_out_x2[i*8:i*8+8] for i in range(4)]
            tmp_gf_out_x3 = gf_out_x3[r][idx*32: idx*32+32]
            tmp_gf_out_x3 = [tmp_gf_out_x3[i*8:i*8+8] for i in range(4)]
            for i in range(4):
                clauses += gf_mult(tmp_data[i], tmp_gf_out_x2[i], 2)
                clauses += gf_mult(tmp_data[i], tmp_gf_out_x3[i], 3)
            tmp_mc_out = s_in[r+1][idx*32: idx*32+32]
            tmp_mc_out = [tmp_mc_out[i*8:i*8+8] for i in range(4)]
            for a,b,c,d,e in zip(tmp_gf_out_x2[0], tmp_gf_out_x3[1], tmp_data[2], tmp_data[3], tmp_mc_out[0]):
                clauses += get_espresso_result_cnf(os.path.join(os.path.dirname(__file__), 'simplified_files/4bit_xor_tt_esp.txt'), [a,b,c,d,e])
            for a,b,c,d,e in zip(tmp_data[0], tmp_gf_out_x2[1], tmp_gf_out_x3[2], tmp_data[3], tmp_mc_out[1]):
                clauses += get_espresso_result_cnf(os.path.join(os.path.dirname(__file__), 'simplified_files/4bit_xor_tt_esp.txt'), [a,b,c,d,e])
            for a,b,c,d,e in zip(tmp_data[0], tmp_data[1], tmp_gf_out_x2[2], tmp_gf_out_x3[3], tmp_mc_out[2]):
                clauses += get_espresso_result_cnf(os.path.join(os.path.dirname(__file__), 'simplified_files/4bit_xor_tt_esp.txt'), [a,b,c,d,e])
            for a,b,c,d,e in zip(tmp_gf_out_x3[0], tmp_data[1], tmp_data[2], tmp_gf_out_x2[3], tmp_mc_out[3]):
                clauses += get_espresso_result_cnf(os.path.join(os.path.dirname(__file__), 'simplified_files/4bit_xor_tt_esp.txt'), [a,b,c,d,e])
    return (clauses, dp_var, var_count)