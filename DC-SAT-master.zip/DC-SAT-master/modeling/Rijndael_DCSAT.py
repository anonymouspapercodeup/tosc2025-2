from util.converter import get_espresso_result_cnf
import os
from pysat.formula import IDPool

Block_Size = 256
Nof_Sbox = 32
Sbox_Size = 8
Prob_var_size = 2
Nof_Column = 8
Nof_Rows = 4

def shift_rows(state):
    data = [[state[i * 32 + j * 8 : i * 32 + j * 8 + 8] for j in range(Nof_Rows)] for i in range(Nof_Column)]
    data = [[data[j][i] for j in range(Nof_Column)] for i in range(Nof_Rows)]
    tmp = [
        data[0],
        data[1][1:] + data[1][:1],
        data[2][3:] + data[2][:3],
        data[3][4:] + data[3][:4]
    ]
    tmp_2 = [[tmp[j][i] for j in range(Nof_Rows)] for i in range(Nof_Column)]
    return tmp_2

def get_Rijndael256_DCSAT_clauses(max_round):
    class Vars:
        s_in, s_out, dp_var, gf_out_x2, gf_out_x3 = [], [], [], [], []

    script_dir = os.path.dirname(os.path.abspath(__file__))
    id_pool = IDPool(start_from=1)

    def gf_mult(i, o, times):
        return get_espresso_result_cnf(
            os.path.join(script_dir, f"simplified_files/aes_gf_x{times}_espresso_result.txt"), i + o
        )

    def initialize_variables(max_round: int, vars: Vars):
        def generate_variables(prefix, round_num, count):
            return [id_pool.id(f'{prefix}_{round_num}_{i}') for i in range(count)]
        for r in range(max_round):
            vars.s_in.append(generate_variables('s_in', r, Block_Size))
            vars.s_out.append(generate_variables('s_out', r, Block_Size))
            vars.dp_var.append(generate_variables('dp_var', r, Prob_var_size * Nof_Sbox))
            vars.gf_out_x2.append(generate_variables('gf_out_x2', r, Block_Size))
            vars.gf_out_x3.append(generate_variables('gf_out_x3', r, Block_Size))
        vars.s_in.append(generate_variables('s_in', max_round, Block_Size))
        return vars.s_in, vars.s_out, vars.dp_var, vars.gf_out_x2, vars.gf_out_x3

    def add_sbox_clauses(clauses, s_in, s_out, dp_var, r):
        for byte_pos in range(Nof_Sbox):
            vars = (
                s_in[r][byte_pos * 8 : byte_pos * 8 + 8]
                + s_out[r][byte_pos * 8 : byte_pos * 8 + 8]
                + dp_var[r][byte_pos * Prob_var_size : byte_pos * Prob_var_size + Prob_var_size]
            )
            cnf_file = os.path.join(script_dir, "simplified_files/AES_DC-SAT_espresso_result.txt")
            sbox_cnf = get_espresso_result_cnf(cnf_file, vars)
            clauses.extend(sbox_cnf)

    def add_mix_columns_clauses(clauses, s_out, gf_out_x2, gf_out_x3, s_in, r):
        shifted = shift_rows(s_out[r])
        for idx in range(Nof_Column):
            tmp_data = shifted[idx]
            tmp_gf_out_x2 = [gf_out_x2[r][i * 8 : (i + 1) * 8] for i in range(idx * 4, (idx + 1) * 4)]
            tmp_gf_out_x3 = [gf_out_x3[r][i * 8 : (i + 1) * 8] for i in range(idx * 4, (idx + 1) * 4)]
            for i in range(Nof_Rows):
                clauses += gf_mult(tmp_data[i], tmp_gf_out_x2[i], 2)
                clauses += gf_mult(tmp_data[i], tmp_gf_out_x3[i], 3)
            tmp_mc_out = [s_in[r + 1][i * 8 : (i + 1) * 8] for i in range(idx * 4, (idx + 1) * 4)]
            xor_file = os.path.join(script_dir, "simplified_files/4bit_xor_tt_esp.txt")
            for a, b, c, d, e in zip(tmp_gf_out_x2[0], tmp_gf_out_x3[1], tmp_data[2], tmp_data[3], tmp_mc_out[0]):
                clauses += get_espresso_result_cnf(xor_file, [a, b, c, d, e])
            for a, b, c, d, e in zip(tmp_data[0], tmp_gf_out_x2[1], tmp_gf_out_x3[2], tmp_data[3], tmp_mc_out[1]):
                clauses += get_espresso_result_cnf(xor_file, [a, b, c, d, e])
            for a, b, c, d, e in zip(tmp_data[0], tmp_data[1], tmp_gf_out_x2[2], tmp_gf_out_x3[3], tmp_mc_out[2]):
                clauses += get_espresso_result_cnf(xor_file, [a, b, c, d, e])
            for a, b, c, d, e in zip(tmp_gf_out_x3[0], tmp_data[1], tmp_data[2], tmp_gf_out_x2[3], tmp_mc_out[3]):
                clauses += get_espresso_result_cnf(xor_file, [a, b, c, d, e])

    vars = Vars()
    clauses = []
    initialize_variables(max_round, vars)
    for r in range(max_round):
        add_sbox_clauses(clauses, vars.s_in, vars.s_out, vars.dp_var, r)
        add_mix_columns_clauses(clauses, vars.s_out, vars.gf_out_x2, vars.gf_out_x3, vars.s_in, r)

    clauses.append([_ for _ in range(1, Block_Size + 1)])

    msv = [item for sublist in vars.dp_var for item in sublist[::2]]
    lsv = [item for sublist in vars.dp_var for item in sublist][1::2]
    return clauses, msv, lsv, id_pool.top
