import argparse
import ast
from itertools import chain, product
import os
import subprocess
import tempfile
import time
from typing import Tuple, List

from pysat.card import CardEnc
from pysat.formula import CNF
from pysat.solvers import Solver
from pysat.process import Processor

from modeling.LED_DP import get_LED_redundant_clauses
from modeling.Midori_DP import get_Midori128_redundant_clauses
from modeling.ARIA_DP import get_ARIA_redundant_clauses
from modeling.Camellia_DP import get_Camellia_DP_clauses
from modeling.AES_DP import get_AES_DP_clauses

def generic_matsui_algorithm(cnf: CNF, round: int, result_dp: List[int], dp_var: List[List[int]], objective_dp: int) -> CNF:
    for i, wt in zip(range(1, round + 1), reversed(result_dp)):
        idp = objective_dp - wt
        for j in range(2):
            selected_vars = dp_var[:i] if j == 0 else dp_var[-i:]
            objective_func = CardEnc.atmost(lits=list(chain.from_iterable(selected_vars)), encoding=8, bound=idp, top_id=cnf.nv)
            cnf.extend(objective_func)
    return cnf


def seq_joint_matsui_algorithm(in_var, dp, result_dp, var_count, round, nof_sbox, nof_vars):
    def _gen_auxiliary_var_s(n, k, var_num):
        # Auxiliary variables (number of s-boxes - 1, see paper: s[])
        auxiliary_var_s = []
        for i in range(n-1):
            auxiliary_var_s.append([])
            for _ in range(k):
                auxiliary_var_s[i].append(var_num)
                var_num += 1
        return (auxiliary_var_s, var_num)
    x = list(chain.from_iterable(in_var))  # List of variables indicating active s-box or probability bits 
    k = dp
    n = len(x)
    ret = []
    if k == 0:
        return [[-(x[i])] for i in range(n)]
    elif k > 0:
        ret = []
        s, vnn = _gen_auxiliary_var_s(n, k, var_count)  # Auxiliary variables for s-box (count - 1)
        ret.append([-(x[0]), (s[0][0])])              # Row 1
        ret.extend([-(s[0][j])] for j in range(1, k))  # Row 2
        ret.extend(t for i in range(1, n-1) for t in [
            [-(x[i]), (s[i][0])],                    # Row 3
            [-(s[i-1][0]), (s[i][0])],               # Row 4
            [-(x[i]), -(s[i-1][k-1])]                # Row 7
            ])
        ret.extend(t for i, j in product(range(1, n-1), range(1, k)) for t in [
            [-(x[i]), -(s[i-1][j-1]), (s[i][j])],     # Row 5
            [-(s[i-1][j]), (s[i][j])]                 # Row 6
            ])
        ret.append([-(x[n-1]), -(s[n-2][k-1])])       # Row 8
        # Setting of Matsui bounding condition
        for r, wt in zip(range(1, round+1), reversed(result_dp)):
            idp = dp - wt
            for direction in range(2):
                if direction == 0:
                    e1, e2 = 1, (nof_sbox * nof_vars * r)
                    ret.extend([-(x[i]), -(s[i-1][idp-1])] for i in range(e1, e2))  # Counter stop clause
                else:
                    e1, e2 = (len(x) - (nof_sbox * nof_vars * r)), len(x) - 1
                    ret.extend([s[e1-1][i], -s[e2-1][i + idp]] for i in range(0, wt))
                    ret.extend([s[e1-1][i], -x[e2], -s[e2-1][i + idp-1]] for i in range(0, wt+1))
        return list(ret)


class external_solver:
    def __init__(self, cnf: CNF, solver_name: str = None, solver_log_name: str = None, num_threads: int = 1) -> None:
        self.solver_name = solver_name
        self.threads = num_threads
        self.solver_log_name = (
            solver_log_name
            if solver_log_name is not None
            else tempfile.NamedTemporaryFile(delete=False, suffix=".log").name
        )
        self.temp_cnf_file = tempfile.NamedTemporaryFile(delete=True, suffix=".cnf")
        self.preprocessor = self.preprocess_cnf(cnf)
        self.elapsed_time = 0.0

    def preprocess_cnf(self, cnf: CNF) -> CNF:
        preprocessor = Processor(bootstrap_with=cnf)
        preprocessed = preprocessor.process()
        self.pp_status = preprocessed.status
        if self.pp_status:
            preprocessed.to_file(self.temp_cnf_file.name)
        return preprocessor
    
    def solve(self) -> bool:
        pass

    def time(self) -> float:
        return self.elapsed_time

    def get_model(self) -> List[int]:
        return self.get_satisfied_variables(self.solver_log_name)

    def check_satisfiability(self, file_name: str) -> bool:
        with open(file_name, "r") as f:
            for line in f:
                if line.startswith("s "):
                    return "UN" not in line
        return False

    def get_satisfied_variables(self, file_name: str) -> List[int]:
        v = []
        with open(file_name, "r") as f:
            for line in f:
                if line.startswith("v "):
                    v.extend(line.strip().split()[1:])
        model = list(map(int, v))[:-1]
        return self.preprocessor.restore(model)


class Mallob(external_solver):
    def __init__(self, cnf: CNF, num_threads: int = 1, num_processes: int = 1, solver_log_name: str = None) -> None:
        super().__init__(cnf, num_threads=num_threads, solver_log_name=solver_log_name, solver_name="mallob")
        self.nof_processes = num_processes
        self.solver_dir = f"sat_solvers/{self.solver_name}"
        self.check_directory(self.solver_dir)
        self.set_mallob_options()

    def check_directory(self, path: str) -> None:
        if not os.path.exists(path):
            os.makedirs(path)
        if not os.path.exists(f"{path}/mallob"):
            self.mallob_build()

    def mallob_build(self) -> None:
        if not os.path.exists(f"{self.solver_dir}/{self.solver_name}"):
            script_path = os.path.join(self.solver_dir, "build_mallob.sh")
            os.chmod(script_path, 0o755)
            subprocess.run(script_path, shell=True)

    def set_mallob_options(self) -> None:
        self.mallob_options = (
            f"-mono={self.temp_cnf_file.name} -seed=110519 "
            f"-v=0 -t={self.threads} -max-lits-per-thread=100000000 "
            f"-buffered-imported-cls-generations=10 -clause-buffer-base-size=5000 -clause-buffer-discount=0.9 "
            f"-clause-filter-clear-interval=200 -strict-clause-length-limit=20 -strict-lbd-limit=20 -satsolver=kkkccl "
            f"-extmem-disk-dir={self.solver_dir}/tmp -processes-per-host=1 -regular-process-allocation=1 -sleep=1000 -trace-dir=/tmp -rpa=1 "
            f"-s2f={self.solver_log_name}"
        )

    def solve(self) -> Tuple[bool, float, List[int]]:
        if self.pp_status is False:
            return False
        start = time.perf_counter()
        subprocess.run(f"cd {self.solver_dir}/mallob/build; mpirun --use-hwthread-cpus -np {self.nof_processes} {self.solver_name} {self.mallob_options} > /dev/null 2>&1",shell=True,)
        self.elapsed_time = time.perf_counter() - start
        sat = self.check_satisfiability(self.solver_log_name)
        # subprocess.run("pgrep mpirun | xargs kill -9 > /dev/null 2>&1", shell=True)
        # subprocess.run("pgrep mallob | xargs kill -9 > /dev/null 2>&1", shell=True)
        # subprocess.run("killall mallob_sat_process > /dev/null 2>&1", shell=True)
        # subprocess.run("rm -f /dev/shm/* > /dev/null 2>&1", shell=True)
        return sat


class Painless(external_solver):
    def __init__(self, cnf: CNF, num_threads: int = 1, num_processes: int = 1, solver_log_name: str = None) -> None:
        super().__init__(cnf, num_threads=num_threads, solver_log_name=solver_log_name, solver_name="painless")
        self.solver_dir = f"sat_solvers/{self.solver_name}"
        self.num_processes = num_processes
        self.check_directory(self.solver_dir)
        self.set_painless_options()

    def check_directory(self, path: str) -> None:
        if not os.path.exists(path):
            os.makedirs(path)
        if not os.path.exists(f"{path}/painless"):
            self.painless_build()

    def painless_build(self) -> None:
        if not os.path.exists(f"{self.solver_dir}/{self.solver_name}"):
            script_path = os.path.join(self.solver_dir, "build_painless.sh")
            os.chmod(script_path, 0o755)
            subprocess.run(script_path, shell=True)

    def set_painless_options(self) -> None:
        self.painless_options = f"-v=0 -c={self.threads} -shr-strat=3 -shr-sleep=100000 -sbva-count=12 -ls-after-sbva=2 -sbva-timeout=1000 -dist=1"

    def solve(self) -> Tuple[bool, float, List[int]]:
        if self.pp_status is False:
            return False
        start = time.perf_counter()
        solver_path = os.path.join(self.solver_dir, "painless/build/release")
        if self.num_processes == 1:
            subprocess.run(f"{os.path.join(solver_path, 'painless_release')} {self.painless_options} {self.temp_cnf_file.name} > {self.solver_log_name}", shell=True)
        else:
            subprocess.run(f"cd {solver_path}; export OMPI_MCA_orte_abort_on_non_zero_status=0; mpirun --use-hwthread-cpus -np {self.num_processes} painless_release {self.painless_options} -simple=1 -mallob=1 {self.temp_cnf_file.name} > {self.solver_log_name}", shell=True)
        self.elapsed_time = time.perf_counter() - start
        sat = self.check_satisfiability(self.solver_log_name)
        return sat


class CipherSolver:
    def __init__(self, cipher: str, start_round: int, end_round: int, num_processes: int = 256, solver_name: str = "mallob", num_threads: int = 1, debug: bool = False) -> None:
        self.cipher = cipher
        self.dp = 0
        self.result = []
        self.time_accum = []
        self.round_time = 0
        self.start_round = start_round
        self.end_round = end_round
        self.num_processes = num_processes
        self.nof_sbox, self.nof_vars = self._set_cipher_params(cipher)
        self.solver_name = solver_name
        self.num_threads = num_threads
        self.debug = debug
        self.attack = "Differential"
        self.check_directory("log_dp")
        
    def check_directory(self, path):
        if not os.path.exists(path):
            os.makedirs(path)
        if not os.path.exists(f"{path}/{self.cipher}"):
            os.makedirs(f"{path}/{self.cipher}")
        if not os.path.exists(f"{path}/{self.cipher}/{self.attack}/log"):
            os.makedirs(f"{path}/{self.cipher}/{self.attack}/log")

    def _set_cipher_params(self, cipher: str) -> Tuple[int, int]:
        cipher_params = {
            "LED": (16, 3),
            "ARIA": (16, 7),
            "Midori": (16, 3),
            "Camellia": (8, 7),
            "AES": (16, 7)
        }
        if cipher not in cipher_params:
            raise ValueError(f"Unknown cipher: {cipher}")
        return cipher_params[cipher]

    def get_clauses(self, max_round: int) -> Tuple[List[List[int]], List[List[int]], int]:
        clause_funcs = {
            "LED": get_LED_redundant_clauses,
            "ARIA": get_ARIA_redundant_clauses,
            "Midori": get_Midori128_redundant_clauses,
            "Camellia": get_Camellia_DP_clauses,
            "AES": get_AES_DP_clauses
        }
        if self.cipher not in clause_funcs:
            raise ValueError(f"Unknown cipher: {self.cipher}")
        return clause_funcs[self.cipher](max_round)

    def solve_sun_seq(self) -> None:
        for current_round in range(self.start_round, self.end_round + 1):
            clauses, dp_var, var_count = self.get_clauses(current_round)
            while True:
                cls_copy = clauses.copy()
                seq_clauses = seq_joint_matsui_algorithm(dp_var, self.dp, self.result, var_count, current_round, self.nof_sbox, self.nof_vars)
                for cls in seq_clauses:
                    if isinstance(cls[0], list):
                        for c in cls:
                            cls_copy.append(c)
                    else:
                        cls_copy.append(cls)
                cnf = CNF(from_clauses=cls_copy)
                
                log_name = os.path.join(os.path.abspath("log_dp"), f"{self.cipher}/{self.attack}/log/{current_round}-R_{'D' if self.attack == 'Differential' else 'L'}CP-{self.dp}_seq.log") if not self.debug else None
                if self.solver_name == "mallob":
                    solver = Mallob(cnf, num_processes=self.num_processes, num_threads=self.num_threads, solver_log_name=log_name)
                elif self.solver_name.startswith("cd") or self.solver_name.startswith("cadical"):
                    solver = Solver(name=self.solver_name, bootstrap_with=cnf.clauses, use_timer=True)
                elif self.solver_name == "painless":
                    solver = Painless(cnf, num_processes=self.num_processes, num_threads=self.num_threads, solver_log_name=log_name)
                else:
                    raise ValueError(f"Unsupported solver: {self.solver_name}")
                sat = solver.solve()
                end = solver.time()
                if sat is None:
                    print("Error")
                    return
                self.round_time += end
                print(f'{self.cipher} {current_round}-R, DCP-{self.dp}, {"S" if sat else "UN-S"}AT, {end:.1f}s')
                self.dp += 1
                if sat:
                    with open(f"log_dp/{self.cipher}/{self.attack}/Exst_seq.txt", "a") as f:
                        print(f'{self.cipher} {current_round}-R, DCP-{self.dp-1}, {self.round_time}', file=f)
                    self.result.append(self.dp - 1)
                    self.time_accum.append(self.round_time)
                    self.round_time = 0
                    break
        print(self.result, self.time_accum)
        
    def solve_kmt(self, bcc=8) -> None:
        self.result = [6,30,54,150,169]
        self.dp = 178
        for current_round in range(self.start_round, self.end_round + 1):
            clauses, dp_var, var_count = self.get_clauses(current_round)
            while True:
                cnf = CNF(from_clauses=clauses)
                cnf.extend(CardEnc.atmost(lits=chain.from_iterable(dp_var), encoding=bcc, bound=self.dp, top_id=cnf.nv))
                cnf = generic_matsui_algorithm(cnf, current_round, self.result, dp_var, self.dp)
                
                log_name = os.path.join(os.path.abspath("log_dp"), f"{self.cipher}/{self.attack}/log/{current_round}-R_{'D' if self.attack == 'Differential' else 'L'}CP-{self.dp}_{'kmt' if bcc==1 else 'tot'}.log") if not self.debug else None
                if self.solver_name == "mallob":
                    solver = Mallob(cnf, num_processes=self.num_processes, num_threads=self.num_threads, solver_log_name=log_name)
                elif self.solver_name.startswith("cd") or self.solver_name.startswith("cadical"):
                    solver = Solver(name=self.solver_name, bootstrap_with=cnf.clauses, use_timer=True)
                elif self.solver_name == "painless":
                    solver = Painless(cnf, num_processes=self.num_processes, num_threads=self.num_threads, solver_log_name=log_name)
                else:
                    raise ValueError(f"Unsupported solver: {self.solver_name}")
                sat = solver.solve()
                end = solver.time()
                if sat is None:
                    print("Error")
                    return
                self.round_time += end
                print(f'{self.cipher} {current_round}-R, DCP-{self.dp}, {"S" if sat else "UN-S"}AT, {end:.1f}s')
                self.dp += 1
                if sat:
                    with open(f"log_dp/{self.cipher}/{self.attack}/Exst_{'kmt' if bcc==1 else 'tot'}.txt", "a") as f:
                        print(f'{self.cipher} {current_round}-R, DCP-{self.dp-1}, {self.round_time:.1f}', file=f)
                    self.result.append(self.dp - 1)
                    self.time_accum.append(self.round_time)
                    self.round_time = 0
                    break
        print(self.result, self.time_accum)

    def solve_PySAT(self) -> None:
        self.dp = 0
        self.result = []
        self.time_accum = []
        self.round_time = 0

        for max_round in range(self.start_round, self.end_round + 1):
            clauses, dp_var, var_count = self.get_clauses(max_round)
            while True:
                cnf = CNF(from_clauses=clauses)
                cnf.extend(CardEnc.atmost(lits=chain.from_iterable(dp_var), encoding=1, bound=self.dp, top_id=cnf.nv))

                with Solver(name="cms", bootstrap_with=cnf, use_timer=True) as solver:
                    sat = solver.solve()
                    self.round_time += solver.time()
                    print(f'{self.cipher} {max_round}-R, DCP-{self.dp}, {"S" if sat else "UN-S"}AT')
                    self.dp += 1
                    if sat:
                        with open(f"log_dp/{self.cipher}/Existing_0.txt", "a") as f:
                            print(f'{self.cipher} {max_round}-R, DCP-{self.dp-1}, {self.round_time:.1f}', file=f)
                        self.result.append(self.dp - 1)
                        self.time_accum.append(self.round_time)
                        self.round_time = 0
                        break
        print(self.result, self.time_accum)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--cipher", help="cipher", type=str, required=True)
    parser.add_argument("-m", "--mode", help="mode", type=str, choices=["seq", "kmt", "tot", "PySAT"], default="seq")
    parser.add_argument("-r", "--start_round", help="start round", type=int, required=True)
    parser.add_argument("-e", "--end_round", help="end round", type=int, required=True)
    parser.add_argument("-p", "--processes", help="number of processes", type=int, default=1)
    parser.add_argument("-n", "--num_threads", help="number of threads", type=int, default=1)
    parser.add_argument("-s", "--solver_name", help="solver name", type=str, default="mallob")
    parser.add_argument("-v", "--verbose", help="verbose", action="store_true", default=False)
    args = parser.parse_args()
    cipher_solver = CipherSolver(args.cipher, args.start_round, args.end_round, num_processes=args.processes, solver_name=args.solver_name, num_threads=args.num_threads, debug=args.verbose)
    if args.mode == "seq":
        cipher_solver.solve_sun_seq()
    elif args.mode == "kmt":
        cipher_solver.solve_kmt()
    elif args.mode == "tot":
        cipher_solver.solve_kmt(bcc=6)
    elif args.mode == "PySAT":
        cipher_solver.solve_PySAT()
    else:
        raise ValueError(f"Unknown mode: {args.mode}")