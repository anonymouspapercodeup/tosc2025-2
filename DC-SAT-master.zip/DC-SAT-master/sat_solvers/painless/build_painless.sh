#!/bin/bash

if ! cd sat_solvers/painless; then
  echo "Directory sat_solvers/painless does not exist."
  exit 1
fi
git clone https://github.com/lip6/painless || { echo "Failed to clone repository"; exit 1; }
cd painless || { echo "Failed to change directory"; exit 1; }
make -j || { echo "Make command failed"; exit 1; }
chmod +x painless