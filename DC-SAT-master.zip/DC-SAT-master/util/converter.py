import codecs


def sol_to_bits(sol, start, end):
    return int("".join(list("1" if e > 0 else "0" for e in sol[start: end])), 2)

def convert_logicfriday_to_cnfvar(cnf_string, var_1, var_2, var_out):
    text = cnf_string
    text = (text.replace(')', '')).split('(')
    var_num = [_ for _ in var_1]
    if var_2 != None:
        var_num += [_ for _ in var_2]
    if type(var_out) is int:
        var_num.append(var_out)
    else:
        var_num += [_ for _ in var_out]
    d = dict([(chr(a), str(i)) for a,i in zip(range(65, 76), var_num)])
    trans_table = str.maketrans(d)
    text = [x.translate(trans_table) for x in text if x!='']
    text = [i.split('+') for i in text]
    text = [[int("-"+ s[:-1]) if s.find("'") > 0 else int(s) for s in st] for st in text]
    return text


# with open('./aes_espresso_result.txt', 'w') as fileobj:
#     subprocess.call(['~/sboxanalyzer/bin/espresso', *["-Dmany", "-estrong", "-epos", "-s", "-t", "-of"], './aes_minterm_tt.txt'], stdout=fileobj)

def get_espresso_result_cnf(espresso_result_file, vars, espresso_cnf_out=None):
    with open(espresso_result_file, 'r') as fileobj:
        espresso_output = fileobj.readlines()
    # Parse the output of ESPRESSO
    bd = len(vars)
    sat_clauses = []
    starting_point = 0
    end_point = 0
    for i in range(len(espresso_output)):
        if ".p" in espresso_output[i]:
            starting_point = i + 1
        if ".e" in espresso_output[i]:
            end_point = i
    for l in espresso_output[starting_point:end_point]:
        line = l[0:bd]
        orclause = []
        for i in range(bd):
            if line[i] == '0':
                orclause.append(vars[i])
            elif line[i] == '1':
                orclause.append(-vars[i])
        sat_clauses.append(orclause)
    if espresso_cnf_out != None:
        print(*sat_clauses, sep='\n', file=codecs.open(espresso_cnf_out, 'w', 'utf-8'))
    return sat_clauses


def get_TT_to_CNF(espresso_result_file, vars, espresso_cnf_out=None):
    with open(espresso_result_file, 'r') as fileobj:
        espresso_output = fileobj.readlines()
    # Parse the output of ESPRESSO
    bd = len(vars)
    sat_clauses = []
    starting_point = 0
    end_point = 0
    for i in range(len(espresso_output)):
        if ".p" in espresso_output[i]:
            starting_point = i + 1
        if ".e" in espresso_output[i]:
            end_point = i
    for l in espresso_output[starting_point:end_point]:
        line = l[0:bd]
        orclause = []
        for i in range(bd):
            if line[i] == '1':
                orclause.append(vars[i])
            elif line[i] == '0':
                orclause.append(-vars[i])
        sat_clauses.append(orclause)
    if espresso_cnf_out != None:
        print(*sat_clauses, sep='\n', file=codecs.open(espresso_cnf_out, 'w', 'utf-8'))
    return sat_clauses


def get_espresso_result_cnf_str(espresso_result_file, vars, espresso_cnf_out=None):
    with open(espresso_result_file, 'r') as fileobj:
        espresso_output = fileobj.readlines()
    # Parse the output of ESPRESSO
    # alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R']
    bd = len(vars)
    sat_clauses = []
    starting_point = 0
    end_point = 0
    for i in range(len(espresso_output)):
        if ".p" in espresso_output[i]:
            starting_point = i + 1
        if ".e" in espresso_output[i]:
            end_point = i
    for l in espresso_output[starting_point:end_point]:
        line = l[0:bd]
        orclause = []
        for i in range(bd):
            if line[i] == '0':
                orclause.append(vars[i])
            elif line[i] == '1':
                orclause.append("~{}".format(vars[i]))
        sat_clauses.append("({})".format(' | '.join(orclause)))
    if espresso_cnf_out != None:
        print(*sat_clauses, sep='\n', file=codecs.open(espresso_cnf_out, 'w', 'utf-8'))
    return sat_clauses
    

if __name__=="__main__":
    alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R']
    alphabet = [i for i in range(17)]
    get_espresso_result_cnf('./aes_espresso_result.txt', alphabet, './aes_espresso_cnf_2.txt')
