def get_AES_PROBINSAT_Linear_clauses(max_round, DC=True):
    from pysat.formula import IDPool
    from dataclasses import dataclass, field

    from aes_sbox_linear_probin import aes_sbox_linear_probin
    from aes_gfx2 import aes_gfx2
    from aes_gfx3 import aes_gfx3
    from op import XOR4
    
    # Constant definitions (for AES)
    BLOCK_SIZE = 128        # Number of bits in one block
    NOF_SBOX = 16           # Number of S-boxes per round (for AES)
    SBOX_SIZE = 8           # Number of bits in one S-box
    PROB_VAR_SIZE = 8       # Number of LCP variables (per S-box)
    NOF_COLUMN = 4          # Number of columns in AES
    NOF_ROWS = 4            # Number of rows in AES

    @dataclass
    class AESVars:
        max_round: int
        vpool: IDPool = field(default_factory=IDPool)
        s_in: list = field(init=False)
        s_out: list = field(init=False)
        dp_var: list = field(init=False)
        gf_out_x2: list = field(init=False)
        gf_out_x3: list = field(init=False)

        def __post_init__(self):
            self.s_in = []
            self.s_out = []
            self.dp_var = []
            self.gf_out_x2 = []
            self.gf_out_x3 = []
            # Generate variables for each round
            for r in range(self.max_round):
                self.s_in.append([self.vpool.id(f"s_in_{r}_{i}") for i in range(BLOCK_SIZE)])
                self.s_out.append([self.vpool.id(f"s_out_{r}_{i}") for i in range(BLOCK_SIZE)])
                self.dp_var.append([self.vpool.id(f"dp_{r}_{i}") for i in range(PROB_VAR_SIZE * NOF_SBOX)])
                self.gf_out_x2.append([self.vpool.id(f"gf2_{r}_{i}") for i in range(BLOCK_SIZE)])
                self.gf_out_x3.append([self.vpool.id(f"gf3_{r}_{i}") for i in range(BLOCK_SIZE)])
            # s_in for the final round (max_round)
            self.s_in.append([self.vpool.id(f"s_in_{self.max_round}_{i}") for i in range(BLOCK_SIZE)])
    #####################################################################################################

    vars_obj = AESVars(max_round=max_round)
    s_in = vars_obj.s_in
    s_out = vars_obj.s_out
    dp_var = vars_obj.dp_var
    gf_out_x2 = vars_obj.gf_out_x2
    gf_out_x3 = vars_obj.gf_out_x3

    def shift_rows(state):
        # state is a list of BLOCK_SIZE length. First divide it into 32-bit (4 S-box) units, and form a 4×4 matrix.
        data = [[state[i * 32 + j * SBOX_SIZE: i * 32 + j * SBOX_SIZE + SBOX_SIZE] for j in range(NOF_ROWS)] for i in range(NOF_COLUMN)]
        data = [[data[j][i] for j in range(NOF_COLUMN)] for i in range(NOF_ROWS)]
        tmp = [
            data[0],
            data[1][1:] + data[1][:1],
            data[2][3:] + data[2][:3],
            data[3][4:] + data[3][:4]
        ]
        tmp_2 = [[tmp[j][i] for j in range(NOF_ROWS)] for i in range(NOF_COLUMN)]
        return tmp_2

    def gf_mult(cnf, inp, out, times):
        return aes_gfx2(cnf, *inp, *out) if times == 2 else aes_gfx3(cnf, *inp, *out)

    clauses = []

    # s_in, s_out, dp_var, gf_out_x2, gf_out_x3 are already generated for each round
    # Initial condition: add all variables of s_in[0] (e.g., 1-128) as clauses
    clauses.append(s_in[0])

    for r in range(max_round):
        # SubBytes: for each S-box
        for byte_pos in range(NOF_SBOX):
            # Each S-box input has SBOX_SIZE bits, dp_var has PROB_VAR_SIZE variables
            vars_list = s_in[r][byte_pos * SBOX_SIZE: byte_pos * SBOX_SIZE + SBOX_SIZE] + \
                        s_out[r][byte_pos * SBOX_SIZE: byte_pos * SBOX_SIZE + SBOX_SIZE] + \
                        dp_var[r][byte_pos * PROB_VAR_SIZE: byte_pos * PROB_VAR_SIZE + PROB_VAR_SIZE]
            aes_sbox_linear_probin(clauses, *vars_list)
        # ShiftRows: for s_out[r]
        shifted = shift_rows(s_out[r])
        # MixColumns (inverse direction):
        for idx in range(NOF_COLUMN):
            tmp_mc_out = s_in[r+1][idx * 32: idx * 32 + 32]
            tmp_mc_out = [tmp_mc_out[i * SBOX_SIZE: i * SBOX_SIZE + SBOX_SIZE] for i in range(NOF_ROWS)]
            tmp_gf_out_x2 = gf_out_x2[r][idx * 32: idx * 32 + 32]
            tmp_gf_out_x2 = [tmp_gf_out_x2[i * SBOX_SIZE: i * SBOX_SIZE + SBOX_SIZE] for i in range(NOF_ROWS)]
            tmp_gf_out_x3 = gf_out_x3[r][idx * 32: idx * 32 + 32]
            tmp_gf_out_x3 = [tmp_gf_out_x3[i * SBOX_SIZE: i * SBOX_SIZE + SBOX_SIZE] for i in range(NOF_ROWS)]
            for i in range(NOF_ROWS):
                gf_mult(clauses, tmp_mc_out[i], tmp_gf_out_x2[i], 2)
                gf_mult(clauses, tmp_mc_out[i], tmp_gf_out_x3[i], 3)
            tmp_data = shifted[idx]
            # Generate constraints for each MixColumns output using XOR4
            for a, b, c, d, e in zip(tmp_gf_out_x2[0], tmp_mc_out[1], tmp_mc_out[2], tmp_gf_out_x3[3], list(tmp_data[0])):
                XOR4(clauses, a, b, c, d, e)
            for a, b, c, d, e in zip(tmp_gf_out_x3[0], tmp_gf_out_x2[1], tmp_mc_out[2], tmp_mc_out[3], list(tmp_data[1])):
                XOR4(clauses, a, b, c, d, e)
            for a, b, c, d, e in zip(tmp_mc_out[0], tmp_gf_out_x3[1], tmp_gf_out_x2[2], tmp_mc_out[3], list(tmp_data[2])):
                XOR4(clauses, a, b, c, d, e)
            for a, b, c, d, e in zip(tmp_mc_out[0], tmp_mc_out[1], tmp_gf_out_x3[2], tmp_gf_out_x2[3], list(tmp_data[3])):
                XOR4(clauses, a, b, c, d, e)

    if DC:
        # dp_var is a list for each round. Flatten all rounds, then extract v8 to v1 every 8 elements
        dp_flat = [var for sublist in dp_var for var in sublist]
        v8 = dp_flat[0::PROB_VAR_SIZE]
        v7 = dp_flat[1::PROB_VAR_SIZE]
        v6 = dp_flat[2::PROB_VAR_SIZE]
        v5 = dp_flat[3::PROB_VAR_SIZE]
        v4 = dp_flat[4::PROB_VAR_SIZE]
        v3 = dp_flat[5::PROB_VAR_SIZE]
        v2 = dp_flat[6::PROB_VAR_SIZE]
        v1 = dp_flat[7::PROB_VAR_SIZE]
        return (clauses, v8, (v7, v6, v5, v4), (v3, v2, v1))
    else:
        return (clauses, dp_var, vars_obj.vpool)