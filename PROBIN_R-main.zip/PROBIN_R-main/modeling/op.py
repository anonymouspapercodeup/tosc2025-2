def XOR2(cnf, in0,  in1,  out):
    cnf.append([-in0, -in1, -out])
    cnf.append([in0, in1, -out])
    cnf.append([in0, -in1, out])
    cnf.append([-in0, in1, out])

def XOR3(cnf, in0, in1, in2, out):
    cnf.append([in0, -in1, -in2, -out])
    cnf.append([-in0, in1, -in2, -out])
    cnf.append([-in0, -in1, in2, -out])
    cnf.append([in0, in1, in2, -out])

    cnf.append([-in0, -in1, -in2, out])
    cnf.append([in0, in1, -in2, out])
    cnf.append([in0, -in1, in2, out])
    cnf.append([-in0, in1, in2, out])
    
def XOR4(cnf, in0, in1, in2, in3, out):
    cnf.append([-in0, -in1, -in2, -in3, -out])
    cnf.append([in0, in1, -in2, -in3, -out])
    cnf.append([in0, -in1, in2, -in3, -out])
    cnf.append([-in0, in1, in2, -in3, -out])

    cnf.append([in0, -in1, -in2, in3, -out])
    cnf.append([-in0, in1, -in2, in3, -out])
    cnf.append([-in0, -in1, in2, in3, -out])
    cnf.append([in0, in1, in2, in3, -out])

    cnf.append([in0, -in1, -in2, -in3, out])
    cnf.append([-in0, in1, -in2, -in3, out])
    cnf.append([-in0, -in1, in2, -in3, out])
    cnf.append([in0, in1, in2, -in3, out])

    cnf.append([-in0, -in1, -in2, in3, out])
    cnf.append([in0, in1, -in2, in3, out])
    cnf.append([in0, -in1, in2, in3, out])
    cnf.append([-in0, in1, in2, in3, out])