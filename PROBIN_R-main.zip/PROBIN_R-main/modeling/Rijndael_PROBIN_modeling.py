from itertools import chain
from pysat.formula import IDPool
from dataclasses import dataclass, field

BLOCK_SIZE = 256        # Number of bits in one block
NOF_SBOX = 32           # Number of S-boxes per round (for Rijndael)
SBOX_SIZE = 8           # Number of bits in one S-box
PROB_VAR_SIZE = 8       # Number of DCP variables (per S-box)
NOF_COLUMN = 8          # Number of columns
NOF_ROWS = 4            # Number of rows

@dataclass
class Vars:
    max_round: int
    isAS : bool
    vpool: IDPool = field(default_factory=IDPool)
    s_in: list = field(init=False)
    s_out: list = field(init=False)
    dp_var: list = field(init=False)
    gf_out_x2: list = field(init=False)
    gf_out_x3: list = field(init=False)

    def __post_init__(self):
        self.s_in = []
        self.s_out = []
        self.dp_var = []
        self.gf_out_x2 = []
        self.gf_out_x3 = []
        # Generate variables for each round
        for r in range(self.max_round):
            self.s_in.append([self.vpool.id(f"s_in_{r}_{i}") for i in range(BLOCK_SIZE)])
            self.s_out.append([self.vpool.id(f"s_out_{r}_{i}") for i in range(BLOCK_SIZE)])
            if self.isAS:
                self.dp_var.append([self.vpool.id(f"dp_{r}_{i}") for i in range(NOF_SBOX)])
            else:
                self.dp_var.append([self.vpool.id(f"dp_{r}_{i}") for i in range(PROB_VAR_SIZE * NOF_SBOX)])
            self.gf_out_x2.append([self.vpool.id(f"gf2_{r}_{i}") for i in range(BLOCK_SIZE)])
            self.gf_out_x3.append([self.vpool.id(f"gf3_{r}_{i}") for i in range(BLOCK_SIZE)])
        # s_in for the final round (max_round)
        self.s_in.append([self.vpool.id(f"s_in_{self.max_round}_{i}") for i in range(BLOCK_SIZE)])


def shift_rows(state):
    data = [[state[i * 32 + j * 8 : i * 32 + j * 8 + 8] for j in range(NOF_ROWS)] for i in range(NOF_COLUMN)]
    data = [[data[j][i] for j in range(NOF_COLUMN)] for i in range(NOF_ROWS)]
    tmp = [
        data[0],
        data[1][1:] + data[1][:1],
        data[2][3:] + data[2][:3],
        data[3][4:] + data[3][:4]
    ]
    tmp_2 = [[tmp[j][i] for j in range(NOF_ROWS)] for i in range(NOF_COLUMN)]
    return tmp_2


def get_Rijndael256_PROBINSAT_Linear_clauses(max_round, isAS=False):

    from modeling.aes_sbox_linear_probin_abc import aes_sbox_linear_probin_abc
    from modeling.aes_sbox_linear_AS import aes_sbox_linear_AS
    from modeling.aes_gfx2 import aes_gfx2
    from modeling.aes_gfx3 import aes_gfx3
    from modeling.op import XOR4
    
    #####################################################################################################

    vars_obj = Vars(max_round=max_round, isAS=isAS)
    s_in = vars_obj.s_in
    s_out = vars_obj.s_out
    dp_var = vars_obj.dp_var
    gf_out_x2 = vars_obj.gf_out_x2
    gf_out_x3 = vars_obj.gf_out_x3

    def gf_mult(cnf, inp, out, times):
        if times == 2:
            aes_gfx2(cnf, *inp, *out)
        else:
            aes_gfx3(cnf, *inp, *out)

    clauses = []

    # s_in, s_out, dp_var, gf_out_x2, gf_out_x3 are already generated for each round
    # Initial condition: add all variables of s_in[0] (e.g., 1-128) as clauses
    clauses.append(s_in[0])

    for r in range(max_round):
        # SubBytes
        nof_prb = 1 if isAS else PROB_VAR_SIZE
        for byte_pos in range(NOF_SBOX):
            # Each S-box input has SBOX_SIZE bits, dp_var has PROB_VAR_SIZE variables
            vars_list = s_in[r][byte_pos * SBOX_SIZE: byte_pos * SBOX_SIZE + SBOX_SIZE] + \
                        s_out[r][byte_pos * SBOX_SIZE: byte_pos * SBOX_SIZE + SBOX_SIZE] + \
                        dp_var[r][byte_pos * nof_prb: byte_pos * nof_prb + nof_prb]
            if isAS:
                aes_sbox_linear_AS(clauses, *vars_list)
            else:
                aes_sbox_linear_probin_abc(clauses, *vars_list)
       
        # ShiftRows
        shifted = shift_rows(s_out[r])
        
        # Transpose of MixColumns
        for idx in range(NOF_COLUMN):
            tmp_mc_out = [s_in[r + 1][i * 8 : (i + 1) * 8] for i in range(idx * NOF_ROWS, (idx + 1) * NOF_ROWS)]
            tmp_gf_out_x2 = gf_out_x2[r][idx*32: idx*32+32]
            tmp_gf_out_x2 = [tmp_gf_out_x2[i*8:i*8+8] for i in range(NOF_ROWS)]
            tmp_gf_out_x3 = gf_out_x3[r][idx*32: idx*32+32]
            tmp_gf_out_x3 = [tmp_gf_out_x3[i*8:i*8+8] for i in range(NOF_ROWS)]
            for i in range(NOF_ROWS):
                gf_mult(clauses, tmp_mc_out[i], tmp_gf_out_x2[i], 2)
                gf_mult(clauses, tmp_mc_out[i], tmp_gf_out_x3[i], 3)
            tmp_data = shifted[idx]
            # 02, 01, 01, 03
            for a, b, c, d, e in zip(tmp_gf_out_x2[0], tmp_mc_out[1], tmp_mc_out[2], tmp_gf_out_x3[3], tmp_data[0]):
                XOR4(clauses, a, b, c, d, e)
            # 03, 02, 01, 01
            for a, b, c, d, e in zip(tmp_gf_out_x3[0], tmp_gf_out_x2[1], tmp_mc_out[2], tmp_mc_out[3], tmp_data[1]):
                XOR4(clauses, a, b, c, d, e)
            # 01, 03, 02, 01
            for a, b, c, d, e in zip(tmp_mc_out[0], tmp_gf_out_x3[1], tmp_gf_out_x2[2], tmp_mc_out[3], tmp_data[2]):
                XOR4(clauses, a, b, c, d, e)
            # 01, 01, 03, 02
            for a, b, c, d, e in zip(tmp_mc_out[0], tmp_mc_out[1], tmp_gf_out_x3[2], tmp_gf_out_x2[3], tmp_data[3]):
                XOR4(clauses, a, b, c, d, e)

    if isAS:
        return (clauses, list(chain.from_iterable(dp_var)), vars_obj)
    else:
        # dp_var is a list for each round. Flatten all rounds, then extract v8 to v1 every 8 elements
        dp_flat = [var for sublist in dp_var for var in sublist]
        v8 = dp_flat[0::PROB_VAR_SIZE]
        v7 = dp_flat[1::PROB_VAR_SIZE]
        v6 = dp_flat[2::PROB_VAR_SIZE]
        v5 = dp_flat[3::PROB_VAR_SIZE]
        v4 = dp_flat[4::PROB_VAR_SIZE]
        v3 = dp_flat[5::PROB_VAR_SIZE]
        v2 = dp_flat[6::PROB_VAR_SIZE]
        v1 = dp_flat[7::PROB_VAR_SIZE]
        return (clauses, v8, (v7, v6, v5, v4), (v3, v2, v1), vars_obj)
