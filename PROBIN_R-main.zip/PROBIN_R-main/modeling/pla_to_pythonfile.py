
import codecs

ESPRESSO_PATH = "espresso"
# wget https://github.com/chipsalliance/espresso/releases/download/v2.4/x86_64-linux-gnu-espresso

def pla_to_pythonfile(pla_file: str, outfile_name: str, nof_func_input: int, func_input_str: str):
    PYTHON_FILE = outfile_name + ".py"
    number_bar = nof_func_input + 1
    with codecs.open(PYTHON_FILE, 'w', 'utf-8') as p:
        p.write(f"def {outfile_name}(cnf, {func_input_str}):\n")
        PLA_FILE = pla_file
        espresso_output = open(PLA_FILE, 'r').readlines()
        start_point, end_point = 0, 0
        for i in range(len(espresso_output)):
            if ".p" in espresso_output[i]:
                start_point = i + 1
            if ".e" in espresso_output[i]:
                end_point = i
        for l in espresso_output[start_point:end_point]:
            line = l[:number_bar]
            p.write("   cnf.append([")
            for b,d in enumerate([func_input_str.split(", ")[i] for i in range(nof_func_input)]):
                if line[b] == '0': p.write(f"{d}, ") 
                elif line[b] == '1' : p.write(f"-{d}, ")
            p.write(f"])\n")
            
def aes():
    # change directory to this file's directory
    import os
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    pla = "pla/AES_sbox_probinS_linear_espressoDmany.pla"
    func_input_str = " ".join([f"i{i}," for i in range(8)])
    func_input_str += " " + " ".join([f"o{i}," for i in range(8)])
    func_input_str += " " + " ".join([f"p{i}," for i in range(8)])[:-1]
    pla_to_pythonfile(pla, "aes_sbox_linear_probin", 24, func_input_str)
    pla = "pla/AES_sbox_probinS_linear_espressoDsimplify_abc.pla"
    func_input_str = " ".join([f"i{i}," for i in range(8)])
    func_input_str += " " + " ".join([f"o{i}," for i in range(8)])
    func_input_str += " " + " ".join([f"p{i}," for i in range(8)])[:-1]
    pla_to_pythonfile(pla, "aes_sbox_linear_probin_abc", 24, func_input_str)
    
def aes_gf():
    import os
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    pla = "pla/aes_gf_x2_espresso_result.txt"
    func_input_str = " ".join([f"i{i}," for i in range(8)])
    func_input_str += " " + " ".join([f"o{i}," for i in range(8)])[:-1]
    pla_to_pythonfile(pla, "aes_gfx2", 16, func_input_str)
    pla = "pla/aes_gf_x3_espresso_result.txt"
    func_input_str = " ".join([f"i{i}," for i in range(8)])
    func_input_str += " " + " ".join([f"o{i}," for i in range(8)])[:-1]
    pla_to_pythonfile(pla, "aes_gfx3", 16, func_input_str)

def AS():
    import os
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    pla = "pla/AES_sbox_AS_linear_espresso.pla"
    func_input_str = " ".join([f"i{i}," for i in range(8)])
    func_input_str += " " + " ".join([f"o{i}," for i in range(8)])
    func_input_str += " " + " ".join([f"p{i}," for i in range(1)])[:-1]
    pla_to_pythonfile(pla, "aes_sbox_linear_AS", 17, func_input_str)
    
     
if __name__ == "__main__":
    AS()
    # aes_gf()
    # aes()