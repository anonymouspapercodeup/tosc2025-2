import datetime
import math
import os
import sys
from dataclasses import dataclass, field

from pysat.card import CardEnc
from pysat.formula import CNF

from modeling.AES_PROBIN_modeling import get_AES_PROBINSAT_Linear_clauses
from lib.probin_helper import DecimalPartSearchHelper, IntegerPartSearchHelper
from lib.util import custom_printing, set_logger
from lib.solvers import Solver_Wrapper


class MatsuiBoundingConditionHelper:
    nof_vars = 8  # number of AS & integer & decimal variables

    def __init__(self, max_round, cnf, known_weights, target_weight, vars, original_bounds, known_AS_low, max_hw_i, min_hw_i, max_hw_d, min_hw_d=None):
        self.max_round = max_round
        self.cnf = cnf
        self.known_weights = known_weights
        self.target_weight = target_weight
        self.vars = vars
        self.original_bounds = original_bounds
        self.known_AS_low = known_AS_low
        self.max_hw_i = max_hw_i
        self.min_hw_i = min_hw_i
        self.max_hw_d = max_hw_d
        self.min_hw_d = None if min_hw_d is None else min_hw_d
        
    def __matsui_divide_milp_solve(self, weightBest_in_round, weightEst_minus_Best, AS_low, maximization_target):
        from sage.all import ZZ
        from sage.numerical.mip import (MIPSolverException, MixedIntegerLinearProgram)
        p = MixedIntegerLinearProgram(maximization=True, solver="GLPK")
        k = p.new_variable(integer=True, nonnegative=True)
        p.add_constraint(8 * k[0] + 4 * k[1] + 2 * k[2] + k[3] + 0.830 * k[4] + 0.385 * k[5] + 0.356 * k[6] <= weightEst_minus_Best)
        for j in range(self.nof_vars):
            p.add_constraint(0 <= k[j])
        p.add_constraint(AS_low <= k[self.nof_vars - 1])
        p.add_constraint(AS_low * self.min_hw_i <= k[0] + k[1] + k[2] + k[3])
        if self.min_hw_d is not None:
            p.add_constraint(AS_low * self.min_hw_d <= k[4] + k[5] + k[6])
        p.add_constraint(k[0] + k[1] + k[2] + k[3] <= k[self.nof_vars - 1] * self.max_hw_i)
        p.add_constraint(k[4] + k[5] + k[6] <= k[self.nof_vars - 1] * self.max_hw_d)
        p.add_constraint(weightBest_in_round <= 8 * k[0] + 4 * k[1] + 2 * k[2] + k[3] + 0.830 * k[4] + 0.385 * k[5] + 0.356 * k[6])
        for j, s in zip(range(self.nof_vars), self.original_bounds):
            p.add_constraint(k[j] <= s)
        p.set_objective(k[maximization_target])
        try:
            return int(p.solve())
        except Exception:
            return None
    
    def get_Matsui_CNF(self):
        nb_sboxes = 8
        for i in range(1, self.max_round):
            weightEst_minus_Best = self.target_weight - self.known_weights[self.max_round - i]
            weightBest_in_round = self.known_weights[i]
            AS_low = self.known_AS_low[i]
            matsui_bound = self.__matsui_divide_milp_solve(weightBest_in_round, weightEst_minus_Best, AS_low, self.nof_vars - 1)
            if matsui_bound is not None:
                for direction in range(2):
                    lits = self.vars[0][: (i * nb_sboxes)] if direction == 0 else self.vars[0][-(i * nb_sboxes):]
                    self.cnf.extend(CardEnc.atmost(lits=lits, encoding=8, bound=matsui_bound, top_id=self.cnf.nv).clauses)
            for maximization_target in range(1, self.nof_vars):
                matsui_bound = self.__matsui_divide_milp_solve(weightBest_in_round, weightEst_minus_Best, AS_low, maximization_target)
                if matsui_bound is not None:
                    if matsui_bound < self.original_bounds[maximization_target]:
                        for direction in range(2):
                            lits = self.vars[maximization_target][: (i * nb_sboxes)] if direction == 0 else self.vars[maximization_target][-(i * nb_sboxes):]
                            self.cnf.extend(CardEnc.atmost(lits=lits, encoding=8, bound=matsui_bound, top_id=self.cnf.nv).clauses)
        return self.cnf


class PrintUtil:
    @staticmethod
    def calc_dcp(sol, max_round):
        """AES version DCP calculation. Processes a block of 16 bytes x 8 bits per round"""
        nof_vars = 8
        dcp = 0
        var_count = 0
        for r in range(max_round):
            var_count += 128
            var_count += 128
            dp_var = sol[var_count: var_count + (16 * nof_vars)]
            # Extract each byte of 16 bytes by 8 bits
            dp_var = [sol[i * nof_vars + var_count: i * nof_vars + var_count + nof_vars] for i in range(16)]
            dp_var_sqr = ["".join("1" if e > 0 else "0" for e in byte) for byte in dp_var]
            one_round_dcps = []
            for e in dp_var_sqr:
                if e == "0 0000 000":
                    continue
                elif e == "1 0110 000":
                    one_round_dcps.append(6.0)
                elif e == "1 0110 010":
                    one_round_dcps.append(6.385)
                elif e == "1 0110 100":
                    one_round_dcps.append(6.830)
                elif e == "1 0111 001":
                    one_round_dcps.append(7.356)
                elif e == "1 1000 000":
                    one_round_dcps.append(8.0)
                elif e == "1 1000 100":
                    one_round_dcps.append(8.830)
                elif e == "1 1010 000":
                    one_round_dcps.append(10.0)
                elif e == "1 1100 000":
                    one_round_dcps.append(12.0)
                else:
                    custom_printing(f"ERROR @ DCP value -> {e}")
            one_round_dcp = sum(one_round_dcps)
            dcp += one_round_dcp
            var_count += 16 * nof_vars
            var_count += 128
            var_count += 128
        return dcp


@dataclass(frozen=True)
class AESConfig:
    known_AS: tuple = (0, 1, 5, 9, 25, 26, 30, 34, 50, 51, 55, 71)
    combination_element: tuple = ("0110", "0111", "1000", "1010", "1100")
    decimal_combination_element: tuple = ("000", "001", "010", "100")
    integer_assignment: tuple = (8, 4, 2, 1)
    decimal_assignment: tuple = (0.830, 0.385, 0.356)
    Sbox_DP_max: int = 6
    max_hw_i: int = 3
    min_hw_i: int = 1
    max_hw_d: int = 1
    min_hw_d: int = None
    LOG_FILE: str = "log/AES/PROBIN.txt"


@dataclass
class AESCharacteristicSearch:
    start_round: int
    end_round: int
    config: AESConfig = AESConfig()
    result_dcp: list = field(default_factory=lambda: [0])
    round_time: float = 0.0

    def __post_init__(self):
        # Initialize log output
        set_logger(self.config.LOG_FILE)

    def get_time(self) -> str:
        return datetime.datetime.now().strftime('[%Y/%m/%d %H:%M:%S]')

    def __single_SAT_search(self, max_round, clauses, vars, dcp, bounds,
                              only_integer=True, matsui=False, is_decimal_eq=True):
        v8, v7, v6, v5, v4, v3, v2, v1 = vars
        i, j, k, l, m, n, o = bounds
        cnf = CNF(from_clauses=clauses)
        # Add equality constraints for the integer part
        cnf.extend(CardEnc.equals(lits=v7, encoding=8, bound=i, top_id=cnf.nv).clauses)
        cnf.extend(CardEnc.equals(lits=v6, encoding=8, bound=j, top_id=cnf.nv).clauses)
        cnf.extend(CardEnc.equals(lits=v5, encoding=8, bound=k, top_id=cnf.nv).clauses)
        cnf.extend(CardEnc.equals(lits=v4, encoding=8, bound=l, top_id=cnf.nv).clauses)
        if not only_integer:
            if is_decimal_eq:
                cnf.extend(CardEnc.equals(lits=v3, encoding=8, bound=m, top_id=cnf.nv).clauses)
                cnf.extend(CardEnc.equals(lits=v2, encoding=8, bound=n, top_id=cnf.nv).clauses)
                cnf.extend(CardEnc.equals(lits=v1, encoding=8, bound=o, top_id=cnf.nv).clauses)
            else:
                cnf.extend(CardEnc.atmost(lits=v3, encoding=8, bound=m, top_id=cnf.nv).clauses)
                cnf.extend(CardEnc.atmost(lits=v2, encoding=8, bound=n, top_id=cnf.nv).clauses)
                cnf.extend(CardEnc.atmost(lits=v1, encoding=8, bound=o, top_id=cnf.nv).clauses)
        if matsui and (max_round > 1):
            # Delegate Matsui conditions to helper class
            calc_decimal = lambda a: sum(b * c for b, c in zip(a, (8, 4, 2, 1, 0.830, 0.385, 0.356)))
            original_bounds = bounds if only_integer else [i, j, k, l] + [self.config.known_AS[max_round]] * 3
            target_weight = calc_decimal(original_bounds)
            known_weights, AS_low = self.result_dcp, self.config.known_AS
            matsui_helper = MatsuiBoundingConditionHelper(
                max_round, cnf, known_weights, target_weight, vars,
                original_bounds, AS_low, self.config.max_hw_i, self.config.min_hw_i, self.config.max_hw_d, self.config.min_hw_d
            )
            cnf = matsui_helper.get_Matsui_CNF()
        solver = Solver_Wrapper(cnf, hosts_setting={"localhost": int(os.cpu_count() / 4)})
        sat, end, model = solver.solve()
        self.round_time += end
        custom_printing(f"AES {max_round}-R, DCP-{dcp}, Bounds: {bounds}, {'SAT' if sat else 'UNSAT'}, {end:.5f}")
        if sat == "":
            sys.exit(-1)
        dcp_val = 0
        if sat:
            dcp_val = PrintUtil.calc_dcp(model, max_round)
            custom_printing(f"\t-> SAT DCP: {dcp_val}")
        return sat, model, dcp_val

    def __is_upper_bound(self, max_round, matsui=True):
        start = max(self.config.known_AS[max_round] - 1, 0)
        for upper_bound in [start, self.config.known_AS[max_round]]:
            clauses, v8, (v7, v6, v5, v4), (v3, v2, v1) = get_AES_PROBINSAT_Linear_clauses(max_round)
            dcp = upper_bound * self.config.Sbox_DP_max
            bounds = [0, upper_bound, upper_bound, 0, 0, 0, 0]
            var_all = (v8, v7, v6, v5, v4, v3, v2, v1)
            sat, model, sat_dcp = self.__single_SAT_search(max_round, clauses, var_all, dcp, bounds,
                                                            only_integer=False, matsui=matsui)
            if sat:
                self.result_dcp.append(sat_dcp)
                return True
        return False

    def __decimal_part_search(self, max_round, matsui=True):
        clauses, v8, (v7, v6, v5, v4), (v3, v2, v1) = get_AES_PROBINSAT_Linear_clauses(max_round)
        var_all = (v8, v7, v6, v5, v4, v3, v2, v1)
        # Use IntegerPartSearchHelper for integer part search
        AS_low = self.config.known_AS[max_round]
        prob_start = int(math.floor(AS_low * self.config.Sbox_DP_max))
        for prob_integer in range(prob_start, int((max_round * 16) * round(self.config.Sbox_DP_max, 0))):
            isearcher = IntegerPartSearchHelper(
                self.config.integer_assignment, self.config.combination_element,
                prob_integer, AS_low, self.config.Sbox_DP_max
            )
            space = isearcher.generate_solution_space()
            AS_upper = isearcher.AS_max
            custom_printing(f"Prob(int)={prob_integer} {space}")
            for t_i in space:
                sat, model, sat_dcp = self.__single_SAT_search(
                    max_round, clauses, var_all,
                    prob_integer, list(t_i) + ["any"] * len(self.config.decimal_assignment),
                    only_integer=True, matsui=matsui
                )
                if sat:
                    tmp_detected_dcp = sat_dcp
                    tmp_detected_decimal = sat_dcp - prob_integer
                    if tmp_detected_decimal != 0:
                        threshold, sat_dcp, model = self.__search_minimum_weight_any_one(
                            max_round, clauses, var_all, prob_integer,
                            list(t_i), len(self.config.decimal_assignment), AS_upper
                        )
                        if threshold != 0:
                            dcm = DecimalPartSearchHelper(
                                self.config.decimal_assignment, self.config.decimal_combination_element,
                                AS_upper, tmp_detected_decimal, threshold
                            )
                            sat_state = "Start"
                            end_state = "CONTINUE"
                            calc_decimal = lambda a: sum(b * c for b, c in zip(a, self.config.decimal_assignment))
                            while end_state == "CONTINUE":
                                for t_d in dcm.next(sat_state):
                                    sum_decimal = calc_decimal(t_d)
                                    current_dcp = prob_integer + sum_decimal
                                    vars_comb = list(t_i) + list(t_d)
                                    if self.__precheck_solution_space(tmp_detected_dcp, vars_comb, AS_low):
                                        if (dcm.search_prob + prob_integer >= tmp_detected_dcp) or (dcm.search_prob + prob_integer >= tmp_detected_dcp):
                                            current_dcp = tmp_detected_dcp if tmp_detected_dcp < current_dcp else current_dcp
                                            sum_decimal = tmp_detected_decimal
                                            end_state = "END"
                                            break
                                        custom_printing(f"\t... Search for prob. with {prob_integer}+{dcm.search_prob} ({t_d})")
                                        sat, model, sat_dcp = self.__single_SAT_search(
                                            max_round, clauses, var_all, prob_integer,
                                            list(t_i) + list(t_d), only_integer=False, matsui=True
                                        )
                                        if sat:
                                            sum_decimal = calc_decimal(t_d)
                                            current_dcp = prob_integer + sum_decimal
                                            end_state = "END"
                                            break
                                    else:
                                        custom_printing("\t\tSKIP: " + " ".join(map(str, list(t_i) + list(t_d))))
                                        sat_state = False
                                        continue
                    else:
                        current_dcp = prob_integer
                    if current_dcp < 1000:
                        return current_dcp, model
        return 1000, None

    def __search_minimum_weight_any_one(self, max_round, clauses, var_all, prob_integer, bounds, length, AS_upper):
        for threshold in range(AS_upper):
            sat, model, sat_dcp = self.__single_SAT_search(
                max_round, clauses, var_all, prob_integer,
                list(bounds) + [threshold] * length, only_integer=False, matsui=True, is_decimal_eq=False
            )
            if sat:
                return threshold, sat_dcp, model
        return 0, 0, None

    def __precheck_solution_space(self, target_prob, vars, AS_low):
        from sage.all import ZZ
        from sage.numerical.mip import MixedIntegerLinearProgram
        nof_vars = 8
        p = MixedIntegerLinearProgram(maximization=False, solver="GLPK")
        k = p.new_variable(integer=True, nonnegative=True)
        for n, v in enumerate(vars):
            p.add_constraint(k[n] == v)
        p.add_constraint(8*k[0]+4*k[1]+2*k[2]+k[3] + 0.830*k[4]+0.385*k[5]+0.356*k[6] == target_prob)
        for j in range(nof_vars-1):
            p.add_constraint(0 <= k[j])
            p.add_constraint(k[j] <= k[nof_vars-1])
        p.add_constraint(AS_low <= k[nof_vars-1])
        p.add_constraint(AS_low * self.config.min_hw_i <= k[0]+k[1]+k[2]+k[3])
        if self.config.min_hw_d is not None:
            p.add_constraint(AS_low * self.config.min_hw_d <= k[4]+k[5]+k[6])
        p.add_constraint((k[0]+k[1]+k[2]+k[3]) <= k[nof_vars-1] * self.config.max_hw_i)
        p.add_constraint((k[4]+k[5]+k[6]) <= k[nof_vars-1] * self.config.max_hw_d)
        try:
            p.solve()
            return True
        except Exception:
            return False

    def run(self):
        for max_round in range(self.start_round, self.end_round):
            self.round_time = 0
            matsui = True
            if not self.__is_upper_bound(max_round, matsui=matsui):
                dcp, model = self.__decimal_part_search(max_round, matsui=matsui)
                self.result_dcp.append(dcp)
            custom_printing(f"AES {max_round}-R, {self.round_time:.3f}[sec]")
            custom_printing(str(self.result_dcp) + "\n")

    def AS(self):
        def print_solution(sol, max_round):
            var_count = 0
            for r in range(max_round):
                s_in = [sol[i * 8 + var_count: i * 8 + var_count + 8] for i in range(16)]
                s_in_sqr = ["".join("■" if e > 0 else "□" for e in byte) for byte in s_in]
                var_count += 128
                var_count += 256 * 16
                var_count += 256 * 16
                custom_printing("s_in : " + " ".join(s_in_sqr))
                s_out = [sol[i * 8 + var_count: i * 8 + var_count + 8] for i in range(16)]
                s_out_sqr = ["".join("■" if e > 0 else "□" for e in byte) for byte in s_out]
                var_count += 128
                dp_var = sol[var_count: var_count + (8 * 16)]
                dp_var = [sol[i * 8 + var_count: i * 8 + var_count + 8] for i in range(16)]
                dp_var_sqr = ["".join("■" if e > 0 else "□" for e in byte) for byte in dp_var]
                var_count += 8 * 16
                custom_printing("s_out: " + " ".join(s_out_sqr) + "\nAS-DCP: " + " ".join(dp_var_sqr))
            out = [sol[i * 8 + var_count: i * 8 + var_count + 8] for i in range(16)]
            out_str = ["".join("■" if e > 0 else "□" for e in byte) for byte in out]
            custom_printing("out  : " + " ".join(out_str))
        result_AS = [0]
        # Switch log file for AS output
        set_logger("/home/hoge/AES_Linear_PROBINSAT_AS.txt")
        nof_AS = 1
        for max_round in range(self.start_round, self.end_round):
            cnf, v8, a, b, vpool = get_AES_PROBINSAT_Linear_clauses(max_round)
            while True:
                cnf.extend(CardEnc.atmost(lits=v8, encoding=8, bound=nof_AS, vpool=vpool))
                file_name_base = f'/home/hoge/AES_Linear_{max_round}R_PROBINSAT_AS-{nof_AS}'
                solver = Solver_Wrapper(cnf, file_name_base + ".log")
                sat, end, model = solver.solve()
                s = f'{file_name_base}, {"S" if sat else "UN-S"}AT, {end:.5f}'
                custom_printing(s)
                if sat == "":
                    sys.exit(-1)
                if sat:
                    result_AS.append(nof_AS)
                    print_solution(model, max_round)
                    custom_printing("Result AS: " + str(result_AS[1:]))
                    nof_AS += 1
                    break
                else:
                    nof_AS += 1

if __name__ == "__main__":
    searcher = AESCharacteristicSearch(start_round=1, end_round=6)
    custom_printing(searcher.get_time())
    searcher.run()