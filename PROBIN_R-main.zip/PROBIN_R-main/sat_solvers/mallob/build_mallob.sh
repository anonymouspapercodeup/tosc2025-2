#!/bin/bash
set -e

# if ! cd sat_solvers/mallob; then
#   echo "Directory sat_solvers/mallob does not exist."
#   exit 1
# fi

if ! git clone https://github.com/domschrei/mallob; then
  echo "Failed to clone repository."
  exit 1
fi

if ! cd mallob/lib; then
  echo "Directory mallob/lib does not exist."
  exit 1
fi

if ! bash fetch_and_build_solvers.sh klcym; then
  echo "Failed to fetch and build solvers."
  exit 1
fi

cd ..

if ! sed -i 's/^new_test.*$//g' CMakeLists.txt src/app/sat/setup.cmake; then
  echo "Failed to modify CMakeLists.txt or setup.cmake."
  exit 1
fi

mkdir -p build && cd build

if ! cmake -DCMAKE_BUILD_TYPE=RELEASE -DMALLOB_USE_ASAN=0 -DMALLOB_ASSERT=1 -DMALLOB_ASSERT_HEAVY=0 -DMALLOB_USE_JEMALLOC=1 -DMALLOB_JEMALLOC_DIR=/usr/lib/x86_64-linux-gnu -DMALLOB_LOG_VERBOSITY=0 -DMALLOB_SUBPROC_DISPATCH_PATH=\"./\" -DMALLOB_APP_SAT=1 -DMALLOB_USE_GLUCOSE=0 -DMALLOB_MAX_N_APPTHREADS_PER_PROCESS=64 ..; then
  echo "CMake configuration failed."
  exit 1
fi

if ! make -j; then
  echo "Make command failed."
  exit 1
fi