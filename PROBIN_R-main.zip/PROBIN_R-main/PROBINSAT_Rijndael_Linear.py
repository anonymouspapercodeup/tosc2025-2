import datetime
import math
import os
import sys
from dataclasses import dataclass, field

from pysat.card import CardEnc
from pysat.formula import CNF

from modeling.Rijndael_PROBIN_modeling import get_Rijndael256_PROBINSAT_Linear_clauses, BLOCK_SIZE, NOF_SBOX, SBOX_SIZE, PROB_VAR_SIZE, NOF_COLUMN, NOF_ROWS
from lib.probin_helper import DecimalPartSearchHelper, IntegerPartSearchHelper
from lib.util import custom_printing, set_logger
from lib.solvers import Solver_Wrapper


class MatsuiBoundingConditionHelper:
    def __init__(self, max_round, cnf, known_weights, target_weight, vars, original_bounds, known_AS_low, max_hw_i, min_hw_i, max_hw_d, min_hw_d=None):
        self.max_round = max_round
        self.cnf = cnf
        self.known_weights = known_weights
        self.target_weight = target_weight
        self.vars = vars
        self.original_bounds = original_bounds
        self.known_AS_low = known_AS_low
        self.max_hw_i = max_hw_i
        self.min_hw_i = min_hw_i
        self.max_hw_d = max_hw_d
        self.min_hw_d = None if min_hw_d is None else min_hw_d
        
    def __matsui_divide_milp_solve(self, weightBest_in_round, weightEst_minus_Best, AS_low, maximization_target):
        from sage.all import ZZ
        from sage.numerical.mip import (MIPSolverException, MixedIntegerLinearProgram)
        p = MixedIntegerLinearProgram(maximization=True, solver="GLPK")
        k = p.new_variable(integer=True, nonnegative=True)
        p.add_constraint(8 * k[0] + 4 * k[1] + 2 * k[2] + k[3] + 0.830 * k[4] + 0.385 * k[5] + 0.356 * k[6] <= weightEst_minus_Best)
        for j in range(PROB_VAR_SIZE):
            p.add_constraint(0 <= k[j])
        p.add_constraint(AS_low <= k[PROB_VAR_SIZE - 1])
        p.add_constraint(AS_low * self.min_hw_i <= k[0] + k[1] + k[2] + k[3])
        if self.min_hw_d is not None:
            p.add_constraint(AS_low * self.min_hw_d <= k[4] + k[5] + k[6])
        p.add_constraint(k[0] + k[1] + k[2] + k[3] <= k[PROB_VAR_SIZE - 1] * self.max_hw_i)
        p.add_constraint(k[4] + k[5] + k[6] <= k[PROB_VAR_SIZE - 1] * self.max_hw_d)
        p.add_constraint(weightBest_in_round <= 8 * k[0] + 4 * k[1] + 2 * k[2] + k[3] + 0.830 * k[4] + 0.385 * k[5] + 0.356 * k[6])
        for j, s in zip(range(PROB_VAR_SIZE), self.original_bounds):
            p.add_constraint(k[j] <= s)
        p.set_objective(k[maximization_target])
        try:
            return int(p.solve())
        except Exception:
            return None
    
    def get_Matsui_CNF(self):
        for i in range(1, self.max_round):
            weightEst_minus_Best = self.target_weight - self.known_weights[self.max_round - i]
            weightBest_in_round = self.known_weights[i]
            AS_low = self.known_AS_low[i]
            matsui_bound = self.__matsui_divide_milp_solve(weightBest_in_round, weightEst_minus_Best, AS_low, PROB_VAR_SIZE - 1)
            if matsui_bound is not None:
                for direction in range(2):
                    lits = self.vars[0][: (i * PROB_VAR_SIZE)] if direction == 0 else self.vars[0][-(i * PROB_VAR_SIZE):]
                    self.cnf.extend(CardEnc.atmost(lits=lits, encoding=8, bound=matsui_bound, top_id=self.cnf.nv).clauses)
            for maximization_target in range(1, PROB_VAR_SIZE):
                matsui_bound = self.__matsui_divide_milp_solve(weightBest_in_round, weightEst_minus_Best, AS_low, maximization_target)
                if matsui_bound is not None:
                    if matsui_bound < self.original_bounds[maximization_target]:
                        for direction in range(2):
                            lits = self.vars[maximization_target][: (i * PROB_VAR_SIZE)] if direction == 0 else self.vars[maximization_target][-(i * PROB_VAR_SIZE):]
                            self.cnf.extend(CardEnc.atmost(lits=lits, encoding=8, bound=matsui_bound, top_id=self.cnf.nv).clauses)
        return self.cnf


def calc_dcp(sol, max_round):
    dcp = 0
    var_count = 0
    mapping = {
        "00000000": None,
        "10110000": 6.0,
        "10110010": 6.385,
        "10110100": 6.830,
        "10111001": 7.356,
        "11000000": 8.0,
        "11000100": 8.830,
        "11010000": 10.0,
        "11100000": 12.0,
    }
    for r in range(max_round):
        var_count += BLOCK_SIZE
        var_count += BLOCK_SIZE
        dp_var = sol[var_count: var_count + (NOF_SBOX * PROB_VAR_SIZE)]
        dp_var = [sol[i * PROB_VAR_SIZE + var_count: i * PROB_VAR_SIZE + var_count + PROB_VAR_SIZE] for i in range(NOF_SBOX)]
        dp_var_sqr = ["".join("1" if e > 0 else "0" for e in byte) for byte in dp_var]
        one_round_dcps = []
        for e in dp_var_sqr:
            value = mapping.get(e, "ERROR")
            if value is None:
                continue
            elif value != "ERROR":
                one_round_dcps.append(value)
            else:
                custom_printing(f"ERROR @ DCP value -> {e}")
        one_round_dcp = sum(one_round_dcps)
        dcp += one_round_dcp
        var_count += NOF_SBOX * PROB_VAR_SIZE
        var_count += BLOCK_SIZE
        var_count += BLOCK_SIZE
    return dcp


@dataclass(frozen=True)
class Config:
    known_AS: tuple = (0, 1, 5, 9, 25, 41, 50, 58, 65, 74, 85)
    combination_element: tuple = ("0110", "0111", "1000", "1010", "1100")
    decimal_combination_element: tuple = ("000", "001", "010", "100")
    integer_assignment: tuple = (8, 4, 2, 1)
    decimal_assignment: tuple = (0.830, 0.385, 0.356)
    Sbox_DP_max: int = 6
    max_hw_i: int = 3
    min_hw_i: int = 1
    max_hw_d: int = 1
    min_hw_d: int = None
    LOG_FILE: str = "log/Rijndael256/PROBIN.log"


@dataclass
class Rijndael256CharacteristicSearch:
    start_round: int
    end_round: int
    log_file: str = "log/Rijndael256/PROBIN.log"
    config: Config = Config()
    result_dcp: list = field(default_factory=lambda: [0])
    round_time: float = 0.0

    def __post_init__(self):
        set_logger(self.config.LOG_FILE)
        from lib.solvers import Mallob
        Mallob.check_directory("sat_solvers")

    def __single_SAT_search(self, max_round, clauses, vars, dcp, bounds, only_integer=True, matsui=False, is_decimal_eq=True):
        v8, v7, v6, v5, v4, v3, v2, v1 = vars
        i, j, k, l, m, n, o = bounds
        cnf = CNF(from_clauses=clauses)
        # Add equality constraints for the integer part
        cnf.extend(CardEnc.equals(lits=v7, encoding=8, bound=i, top_id=cnf.nv).clauses)
        cnf.extend(CardEnc.equals(lits=v6, encoding=8, bound=j, top_id=cnf.nv).clauses)
        cnf.extend(CardEnc.equals(lits=v5, encoding=8, bound=k, top_id=cnf.nv).clauses)
        cnf.extend(CardEnc.equals(lits=v4, encoding=8, bound=l, top_id=cnf.nv).clauses)
        if not only_integer:
            if is_decimal_eq:
                cnf.extend(CardEnc.equals(lits=v3, encoding=8, bound=m, top_id=cnf.nv).clauses)
                cnf.extend(CardEnc.equals(lits=v2, encoding=8, bound=n, top_id=cnf.nv).clauses)
                cnf.extend(CardEnc.equals(lits=v1, encoding=8, bound=o, top_id=cnf.nv).clauses)
            else:
                cnf.extend(CardEnc.atmost(lits=v3, encoding=8, bound=m, top_id=cnf.nv).clauses)
                cnf.extend(CardEnc.atmost(lits=v2, encoding=8, bound=n, top_id=cnf.nv).clauses)
                cnf.extend(CardEnc.atmost(lits=v1, encoding=8, bound=o, top_id=cnf.nv).clauses)
        if matsui and (max_round > 1):
            # Delegate Matsui conditions to helper class
            calc_decimal = lambda a: sum(b * c for b, c in zip(a, (8, 4, 2, 1, 0.830, 0.385, 0.356)))
            original_bounds = bounds if only_integer else [i, j, k, l] + [self.config.known_AS[max_round]] * 3
            target_weight = calc_decimal(original_bounds)
            known_weights, AS_low = self.result_dcp, self.config.known_AS
            matsui_helper = MatsuiBoundingConditionHelper(
                max_round, cnf, known_weights, target_weight, vars,
                original_bounds, AS_low, self.config.max_hw_i, self.config.min_hw_i, self.config.max_hw_d, self.config.min_hw_d
            )
            cnf = matsui_helper.get_Matsui_CNF()
        solver = Solver_Wrapper(cnf, hosts_setting={"localhost": os.cpu_count()-1})
        sat = solver.solve()
        end = solver.elapsed_time
        model = solver.get_model()
        self.round_time += end
        custom_printing(f"Rijndael256 {max_round}-R, DCP-{dcp}, Bounds: {bounds}, {'SAT' if sat else 'UNSAT'}, {end:.5f}")
        if sat == "":
            sys.exit(-1)
        dcp_val = 0
        if sat:
            dcp_val = calc_dcp(model, max_round)
            custom_printing(f"\t-> SAT DCP: {dcp_val}")
        return sat, model, dcp_val

    def __is_upper_bound(self, max_round, matsui=True):
        start = max(self.config.known_AS[max_round] - 1, 0)
        for upper_bound in [start, self.config.known_AS[max_round]]:
            clauses, v8, (v7, v6, v5, v4), (v3, v2, v1), variables = get_Rijndael256_PROBINSAT_Linear_clauses(max_round)
            dcp = upper_bound * self.config.Sbox_DP_max
            bounds = [0, upper_bound, upper_bound, 0, 0, 0, 0]
            var_all = (v8, v7, v6, v5, v4, v3, v2, v1)
            sat, model, sat_dcp = self.__single_SAT_search(max_round, clauses, var_all, dcp, bounds, only_integer=False, matsui=matsui)
            if sat:
                self.result_dcp.append(sat_dcp)
                return True
        return False

    def __decimal_part_search(self, max_round, matsui=True):
        clauses, v8, (v7, v6, v5, v4), (v3, v2, v1), variables = get_Rijndael256_PROBINSAT_Linear_clauses(max_round)
        var_all = (v8, v7, v6, v5, v4, v3, v2, v1)
        AS_low = self.config.known_AS[max_round]
        prob_start = int(math.floor(AS_low * self.config.Sbox_DP_max))
        for prob_integer in range(prob_start, int((max_round * NOF_SBOX) * round(self.config.Sbox_DP_max, 0))):
            isearcher = IntegerPartSearchHelper(
                self.config.integer_assignment, self.config.combination_element,
                prob_integer, AS_low, self.config.Sbox_DP_max
            )
            space = isearcher.generate_solution_space()
            AS_upper = isearcher.AS_max
            custom_printing(f"Prob(int)={prob_integer} {space}")
            for t_i in space:
                sat, model, sat_dcp = self.__single_SAT_search(
                    max_round, clauses, var_all,
                    prob_integer, list(t_i) + ["any"] * len(self.config.decimal_assignment),
                    only_integer=True, matsui=matsui
                )
                if sat:
                    tmp_detected_dcp = sat_dcp
                    tmp_detected_decimal = sat_dcp - prob_integer
                    if tmp_detected_decimal != 0:
                        threshold, sat_dcp, model = self.__search_minimum_weight_any_one(
                            max_round, clauses, var_all, prob_integer,
                            list(t_i), len(self.config.decimal_assignment), AS_upper
                        )
                        if threshold != 0:
                            dcm = DecimalPartSearchHelper(
                                self.config.decimal_assignment, self.config.decimal_combination_element,
                                AS_upper, tmp_detected_decimal, threshold
                            )
                            sat_state = "Start"
                            end_state = "CONTINUE"
                            calc_decimal = lambda a: sum(b * c for b, c in zip(a, self.config.decimal_assignment))
                            while end_state == "CONTINUE":
                                for t_d in dcm.next(sat_state):
                                    sum_decimal = calc_decimal(t_d)
                                    current_dcp = prob_integer + sum_decimal
                                    vars_comb = list(t_i) + list(t_d)
                                    if self.__precheck_solution_space(tmp_detected_dcp, vars_comb, AS_low):
                                        if (dcm.search_prob + prob_integer >= tmp_detected_dcp) or (dcm.search_prob + prob_integer >= tmp_detected_dcp):
                                            current_dcp = tmp_detected_dcp if tmp_detected_dcp < current_dcp else current_dcp
                                            sum_decimal = tmp_detected_decimal
                                            end_state = "END"
                                            break
                                        custom_printing(f"\t... Search for prob. with {prob_integer}+{dcm.search_prob} ({t_d})")
                                        sat, model, sat_dcp = self.__single_SAT_search(
                                            max_round, clauses, var_all, prob_integer,
                                            list(t_i) + list(t_d), only_integer=False, matsui=True
                                        )
                                        if sat:
                                            sum_decimal = calc_decimal(t_d)
                                            current_dcp = prob_integer + sum_decimal
                                            end_state = "END"
                                            break
                                    else:
                                        custom_printing("\t\tSKIP: " + " ".join(map(str, list(t_i) + list(t_d))))
                                        sat_state = False
                                        continue
                    else:
                        current_dcp = prob_integer
                    if current_dcp < 1000:
                        return current_dcp, model
        return 1000, None

    def __search_minimum_weight_any_one(self, max_round, clauses, var_all, prob_integer, bounds, length, AS_upper):
        for threshold in range(AS_upper):
            sat, model, sat_dcp = self.__single_SAT_search(
                max_round, clauses, var_all, prob_integer,
                list(bounds) + [threshold] * length, only_integer=False, matsui=True, is_decimal_eq=False
            )
            if sat:
                return threshold, sat_dcp, model
        return 0, 0, None

    def __precheck_solution_space(self, target_prob, vars, AS_low):
        from sage.all import ZZ
        from sage.numerical.mip import MixedIntegerLinearProgram
        nof_vars = 8
        p = MixedIntegerLinearProgram(maximization=False, solver="GLPK")
        k = p.new_variable(integer=True, nonnegative=True)
        for n, v in enumerate(vars):
            p.add_constraint(k[n] == v)
        p.add_constraint(8*k[0]+4*k[1]+2*k[2]+k[3] + 0.830*k[4]+0.385*k[5]+0.356*k[6] == target_prob)
        for j in range(nof_vars-1):
            p.add_constraint(0 <= k[j])
            p.add_constraint(k[j] <= k[nof_vars-1])
        p.add_constraint(AS_low <= k[nof_vars-1])
        p.add_constraint(AS_low * self.config.min_hw_i <= k[0]+k[1]+k[2]+k[3])
        if self.config.min_hw_d is not None:
            p.add_constraint(AS_low * self.config.min_hw_d <= k[4]+k[5]+k[6])
        p.add_constraint((k[0]+k[1]+k[2]+k[3]) <= k[nof_vars-1] * self.config.max_hw_i)
        p.add_constraint((k[4]+k[5]+k[6]) <= k[nof_vars-1] * self.config.max_hw_d)
        try:
            p.solve()
            return True
        except Exception:
            return False

    def run(self):
        for max_round in range(self.start_round, self.end_round):
            self.round_time = 0
            matsui = True
            if not self.__is_upper_bound(max_round, matsui=matsui):
                dcp, model = self.__decimal_part_search(max_round, matsui=matsui)
                self.result_dcp.append(dcp)
            custom_printing(f"Rijndael256 {max_round}-R, {self.round_time:.3f}[sec]")
            custom_printing(str(self.result_dcp) + "\n")

    def AS(self):
        def print_solution(sol, max_round, vars_obj):
            """
            sol: Solution from SAT solver (list or dictionary with variable IDs as keys)
            max_round: Number of rounds
            vars_obj: Instance of Vars class (contains s_in, s_out, dp_var internally)
            """
            for r in range(max_round):
                # Display s_in (one round)
                s_in_round = []
                for i in range(NOF_SBOX):
                    group_ids = vars_obj.s_in[r][i * SBOX_SIZE : i * SBOX_SIZE + SBOX_SIZE]
                    # Extract values from sol for each variable, display as ■ if 1, □ if 0
                    group_str = "".join("■" if sol[var_id-1] > 0 else "□" for var_id in group_ids)
                    s_in_round.append(group_str)
                print("s_in : " + " ".join(s_in_round))
                
                # Display s_out
                s_out_round = []
                for i in range(NOF_SBOX):
                    group_ids = vars_obj.s_out[r][i * SBOX_SIZE : i * SBOX_SIZE + SBOX_SIZE]
                    group_str = "".join("■" if sol[var_id-1] > 0 else "□" for var_id in group_ids)
                    s_out_round.append(group_str)
                print("s_out: " + " ".join(s_out_round))
                
                # Display dp_var (AS-DCP)
                dp_round = []
                for i in range(NOF_SBOX):
                    group_ids = vars_obj.dp_var[r][i * SBOX_SIZE : i * SBOX_SIZE + SBOX_SIZE]
                    group_str = "".join("■" if sol[var_id-1] > 0 else "□" for var_id in group_ids)
                    dp_round.append(group_str)
                print("Prob : " + " ".join(dp_round))
                print()  # Line break between rounds

            # Display final round (out)
            out_round = []
            final_s_in = vars_obj.s_in[max_round]
            for i in range(NOF_SBOX):
                group_ids = final_s_in[i * SBOX_SIZE : i * SBOX_SIZE + SBOX_SIZE]
                group_str = "".join("■" if sol[var_id-1] > 0 else "□" for var_id in group_ids)
                out_round.append(group_str)
            print("out  : " + " ".join(out_round))

        set_logger("log/Rijndael256/AS.log")
        result_AS = [0]
        nof_AS = 1
        for max_round in range(self.start_round, self.end_round):
            clauses, var_AS, vars_obj = get_Rijndael256_PROBINSAT_Linear_clauses(max_round, isAS=True)
            while True:
                cnf = CNF(from_clauses=clauses)
                cnf.extend(CardEnc.atmost(lits=var_AS, encoding=8, bound=nof_AS, top_id=cnf.nv))
                solver = Solver_Wrapper(cnf, solver_name="kissat")
                sat = solver.solve()
                end = solver.elapsed_time
                custom_printing(f'Rijndael256-{max_round}R_AS-{nof_AS}, {"S" if sat else "UN-S"}AT, {end:.5f}')
                if sat:
                    model = solver.get_model()
                    result_AS.append(nof_AS)
                    for r in range(max_round):
                        dp_round = []
                        for i in range(NOF_SBOX):
                            group_ids = var_AS[NOF_SBOX*r +i]
                            group_str = "■" if model[group_ids-1] > 0 else "□"
                            dp_round.append(group_str)
                        print("Prob : " + " ".join(dp_round))
                    print_solution(model, max_round, vars_obj)
                    custom_printing("Result AS: " + str(result_AS[1:]))
                    nof_AS += 1
                    break
                else:
                    nof_AS += 1

if __name__ == "__main__":
    searcher = Rijndael256CharacteristicSearch(start_round=1, end_round=15)
    # searcher.AS()
    searcher.run()
