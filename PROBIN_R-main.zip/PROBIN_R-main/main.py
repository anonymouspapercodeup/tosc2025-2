import argparse
from dataclasses import dataclass

from PROBINSAT_AES_Linear import AESCharacteristicSearch, AESCharacteristicSearch
from PROBINSAT_Rijndael_Linear import Rijndael256CharacteristicSearch
from lib.util import debug_string

@dataclass
class Options:
    start_round: int = 1
    end_round: int = 6
    algorithm: str = "primitive"
    log_file: str = "log/PRIMITIVE/PROBIN.log"
    AS: bool = False

def parse_args() -> Options:
    parser = argparse.ArgumentParser(description="Linear Characteristic Search")
    parser.add_argument("--start-round", type=int, default=1, help="Starting round")
    parser.add_argument("--end-round", type=int, default=6, help="Ending round")
    parser.add_argument("--algorithm", type=str, choices=["aes", "camellia", "rijndael256"], help="Select algorithm")
    parser.add_argument("--AS", action="store_true", help="Enable AS search")
    parser.add_argument("--log-file", type=str, default="log/PRIMITIVE/PROBIN.txt", help="Path to log file")
    args = parser.parse_args()
    return Options(start_round=args.start_round, end_round=args.end_round, algorithm=args.algorithm, log_file=args.log_file, AS=args.AS)

if __name__ == "__main__":
    # change directory to this file's directory
    import os
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    options = parse_args()
    options.algorithm = options.algorithm.lower()
    if options.algorithm == "aes":
        searcher = AESCharacteristicSearch(options.start_round, options.end_round, options.log_file)
    elif options.algorithm == "camellia":
        pass
    elif options.algorithm == "rijndael256":
        searcher = Rijndael256CharacteristicSearch(options.start_round, options.end_round, options.log_file)
    else:
        raise ValueError("Unsupported algorithm")
    
    try:    
        debug_string(f"Start round: {options.start_round}")
        debug_string(f"End round: {options.end_round}")
        debug_string(f"Algorithm: {options.algorithm}")
        
        if options.AS:
            debug_string("Search for AS: " + str(options.AS))
            searcher.AS()
        else:
            searcher.run()
        debug_string("Finish")
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        debug_string("Error: " + str(e))